package com.sanju.systemx.optimizer

import com.sanju.systemx.caps.Cap
import com.sanju.systemx.caps.Caps
import com.sanju.systemx.device.Detect
import com.sanju.systemx.monitor.Sampler
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.shizuku.CommandResult
import com.sanju.systemx.shizuku.ShizukuBridge

class GpuResult(val step: Step, val floorMhz: Int)

/**
 * Every privileged change goes through here. Rules for each step:
 * 1. Save the original value to the restore journal BEFORE changing anything.
 * 2. Apply through a legitimate Android / vendor interface.
 * 3. Read back where Android allows it. VERIFIED is only returned when a read-back proved it.
 * 4. Report FAILED / UNSUPPORTED honestly. Never report success from an exit code alone.
 */
object Applier {
    val EFFECTS = listOf("COOL", "VIVID", "CINEMATIC", "PERFORMANCE", "DEFAULT")
    val DNS_NAMES = listOf("AUTO", "CLOUDFLARE", "GOOGLE", "QUAD9")
    private val DNS_HOSTS = listOf("", "one.one.one.one", "dns.google", "dns.quad9.net")
    val TOUCH_NAMES = listOf("FAST", "DEFAULT", "SLOW")
    val GPU_LEVELS = listOf("BALANCED", "PERFORMANCE", "MAXIMUM BEST-EFFORT")

    private const val JOURNAL = "journal"
    private val BAD = listOf("error", "usage", "unknown", "exception", "invalid", "not found", "denied", "unsupported")

    // ------------------------------------------------------------------ journal
    private fun load(prefs: Prefs): LinkedHashMap<String, String> {
        val m = LinkedHashMap<String, String>()
        for (l in prefs.getS(JOURNAL, "").lines()) {
            val i = l.indexOf('=')
            if (i > 0) m[l.substring(0, i)] = l.substring(i + 1)
        }
        return m
    }

    private fun save(prefs: Prefs, m: Map<String, String>) {
        prefs.setSNow(JOURNAL, m.entries.joinToString("\n") { it.key + "=" + it.value })
    }

    fun hasJournal(prefs: Prefs): Boolean = load(prefs).isNotEmpty()

    private fun saveOnce(prefs: Prefs, key: String, value: String) {
        val m = load(prefs)
        if (!m.containsKey(key)) { m[key] = value; save(prefs, m) }
    }

    // ------------------------------------------------------------------ helpers
    private fun okCmd(r: CommandResult): Boolean = r.ok && BAD.none { r.out.contains(it, true) }
    private fun okSf(r: CommandResult): Boolean = r.ok && r.out.contains("Parcel(") && !r.out.contains("rror", true)

    private fun same(a: String, b: String): Boolean {
        if (a == b) return true
        val x = a.toFloatOrNull()
        val y = b.toFloatOrNull()
        return x != null && y != null && x == y
    }

    /** Saves the original, writes the value, reads it back. True only when the read-back matches. */
    private fun putSetting(prefs: Prefs, ns: String, key: String, value: String): Boolean {
        saveOnce(prefs, "set:$ns:$key", ShizukuBridge.setting(ns, key))
        val r = ShizukuBridge.sh("settings put $ns $key $value", 3000L, "SETTINGS")
        if (!r.ok) return false
        return same(ShizukuBridge.setting(ns, key), value)
    }

    private fun restoreSetting(ns: String, key: String, v: String): Boolean {
        val cmd = if (v == "null") "settings delete $ns $key" else "settings put $ns $key $v"
        val r = ShizukuBridge.sh(cmd, 3000L, "SETTINGS")
        return r.ok && same(ShizukuBridge.setting(ns, key), v)
    }

    // ------------------------------------------------------------------ DISPLAY
    /** Requests the refresh rate through the standard AOSP keys (plus MIUI's key if that device has it). */
    fun applyDisplay(prefs: Prefs, reqHz: Int): Step {
        if (reqHz <= 0 || !Caps.controllable(Cap.DISPLAY_HIGH_REFRESH)) return Step(St.UNSUPPORTED, Caps.reason(Cap.DISPLAY_HIGH_REFRESH))
        val v = "$reqHz.0"
        val a = putSetting(prefs, "system", "min_refresh_rate", v)
        val b = putSetting(prefs, "system", "peak_refresh_rate", v)
        if (ShizukuBridge.setting("system", "user_refresh_rate") != "null") {
            putSetting(prefs, "system", "user_refresh_rate", reqHz.toString())
        }

        // Vivo/iQOO OriginOS has additional refresh-rate selectors used by its per-app
        // high-refresh policy. Try them only after the standard AOSP keys have been written.
        // The final truth is still Display.refreshRate(), verified by Engine.verifyHz().
        val vendor = android.os.Build.MANUFACTURER.lowercase(java.util.Locale.US)
        var vivoDone = false
        if (vendor.contains("vivo") || vendor.contains("iqoo")) {
            val g = putSetting(prefs, "global", "vivo_screen_refresh_rate_mode", reqHz.toString())
            val s = putSetting(prefs, "secure", "refresh_rate_mode", reqHz.toString())
            vivoDone = g || s
        }
        return if (a || b || vivoDone) {
            Step(St.REQUESTED, "$reqHz Hz requested${if (vivoDone) " + OriginOS refresh selector" else ""}, checking the real panel...")
        } else Step(St.FAILED, "all known refresh-rate controls rejected the request")
    }

    // ------------------------------------------------------------------ GAME MODE
    /**
     * Android's real GameManager path. Older V4 code used `cmd game set --mode performance`,
     * but `set` configures interventions and expects a numeric mode (2 = PERFORMANCE).
     * The actual mode switch is `cmd game mode performance`.
     *
     * On Android 13+ we also configure a modest render downscale (90%) and the real panel FPS
     * target. This is a genuine per-game intervention: lowering the game's render workload can
     * leave more GPU headroom for stable frame pacing on weaker devices. Every change is read
     * back through `list-modes` + `list-configs`; otherwise we fall back to plain PERFORMANCE.
     */
    fun applyGameMode(prefs: Prefs, pkg: String, fps: Int): Step {
        if (!Caps.controllable(Cap.GAME_MODE)) return Step(St.UNSUPPORTED, Caps.reason(Cap.GAME_MODE))

        // Journal both the selected mode and the older intervention backend before any write.
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            val oldOverlay = ShizukuBridge.sh("device_config get game_overlay $pkg 2>/dev/null", 3000L, "GAME_MODE").stdout.trim()
            saveOnce(prefs, "game.overlay:$pkg", oldOverlay.ifEmpty { "null" })
        }
        val before = currentGameMode(pkg) ?: "standard"
        saveOnce(prefs, "game.mode.before:$pkg", before)
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            val scale = prefs.getI("render_scale", 90).coerceIn(50, 100) / 100f
            val scaleText = String.format(java.util.Locale.US, "%.2f", scale)
            val set = ShizukuBridge.sh(
                "cmd game set --mode 2 --downscale $scaleText" + (if (fps > 0) " --fps $fps" else "") + " $pkg 2>&1",
                5000L, "GAME_MODE"
            )
            var configured = okCmd(set)
            if (!configured) {
                // Android builds that expose the older GameManager intervention backend may
                // still accept the per-game device_config overlay. Save the previous value
                // before touching it so restore is exact.
                val fpsPart = if (fps > 0) ",fps=$fps" else ""
                val overlay = "mode=2,downscaleFactor=$scaleText$fpsPart:mode=3,downscaleFactor=$scaleText$fpsPart"
                val fallback = ShizukuBridge.sh("device_config put game_overlay $pkg '$overlay' 2>&1", 5000L, "GAME_MODE")
                configured = okCmd(fallback)
            }
            if (configured) {
                val mode = ShizukuBridge.sh("cmd game mode performance $pkg 2>&1", 5000L, "GAME_MODE")
                val modes = ShizukuBridge.sh("cmd game list-modes $pkg 2>&1", 4000L, "GAME_MODE")
                val configs = ShizukuBridge.sh("cmd game list-configs $pkg 2>&1", 4000L, "GAME_MODE")
                val overlay = ShizukuBridge.sh("device_config get game_overlay $pkg 2>/dev/null", 3000L, "GAME_MODE")
                val modeVerified = okCmd(mode) && modes.out.contains("current mode: performance", true)
                val scaleVerified = configs.out.contains(scaleText) || configs.out.contains(scale.toString()) || overlay.out.contains("downscaleFactor=$scaleText")
                val fpsVerified = fps <= 0 || configs.out.contains("fps-override: $fps") || configs.out.contains("fps=$fps") || configs.out.contains("fps $fps") || overlay.out.contains("fps=$fps")
                if (modeVerified && scaleVerified && fpsVerified) {
                    Caps.markVerified(Cap.GAME_MODE)
                    return Step(St.VERIFIED, "PERFORMANCE + ${scaleText.toFloat().times(100).toInt()}% render scale" + (if (fps > 0) " + $fps FPS target" else ""))
                }
                if (modeVerified) {
                    Caps.markVerified(Cap.GAME_MODE)
                    return Step(St.APPLIED, "PERFORMANCE active; intervention read-back was incomplete")
                }
            }
        }

        // Reliable Android fallback: performance mode without custom intervention.
        val r = ShizukuBridge.sh("cmd game mode performance $pkg 2>&1", 5000L, "GAME_MODE")
        if (!okCmd(r)) return Step(St.FAILED, r.out.take(90).ifEmpty { "performance mode rejected" })
        val verify = ShizukuBridge.sh("cmd game list-modes $pkg 2>&1", 4000L, "GAME_MODE")
        return if (okCmd(verify) && verify.out.contains("current mode: performance", true)) {
            Caps.markVerified(Cap.GAME_MODE)
            Step(St.VERIFIED, "PERFORMANCE mode active")
        } else {
            Step(St.APPLIED, "PERFORMANCE command accepted; mode read-back unavailable")
        }
    }

    private fun currentGameMode(pkg: String): String? {
        val r = ShizukuBridge.sh("cmd game list-modes $pkg 2>&1", 4000L, "GAME_MODE")
        if (!okCmd(r)) return null
        val m = Regex("current mode:\\s*([a-zA-Z_]+)", RegexOption.IGNORE_CASE).find(r.out)
        return m?.groupValues?.getOrNull(1)?.lowercase()
    }

    private fun restoreGameMode(pkg: String, before: String): Boolean {
        // Clear our custom intervention first, then restore the previous selectable mode.
        ShizukuBridge.sh("cmd game reset $pkg 2>&1", 5000L, "GAME_MODE")
        val target = when (before) {
            "performance" -> "performance"
            "battery" -> "battery"
            else -> "standard"
        }
        val r = ShizukuBridge.sh("cmd game mode $target $pkg 2>&1", 5000L, "GAME_MODE")
        return okCmd(r)
    }


    // ------------------------------------------------------------------ CPU
    /** Uses Android's fixed-performance mode first, then a reversible cpufreq floor when a
     * device exposes a writable policy to the shell user. This is a real CPU scheduling hint,
     * not a fake label; every sysfs write is read back before it is reported as verified. */
    fun applyCpu(prefs: Prefs, floorRatio: Float = 0.85f): Step {
        if (Caps.controllable(Cap.CPU_PERFORMANCE)) {
            saveOnce(prefs, "cpu.fixed", "false")
            val r = ShizukuBridge.sh("cmd power set-fixed-performance-mode-enabled true 2>&1", 4000L, "CPU_PERFORMANCE")
            if (okCmd(r)) {
                val g = ShizukuBridge.sh("cmd power get-fixed-performance-mode-enabled 2>&1", 3000L, "CPU_PERFORMANCE")
                if (g.ok && g.out.contains("true", true)) {
                    Caps.markVerified(Cap.CPU_PERFORMANCE)
                    return Step(St.VERIFIED, "fixed performance mode verified")
                }
            }
        }

        val script = """
for p in /sys/devices/system/cpu/cpufreq/policy*; do
  [ -r "§p/cpuinfo_max_freq" ] || continue
  [ -w "§p/scaling_min_freq" ] || continue
  max=§(cat "§p/cpuinfo_max_freq" 2>/dev/null)
  old=§(cat "§p/scaling_min_freq" 2>/dev/null)
  [ -n "§max" ] || continue
  [ -n "§old" ] || continue
  floor=§(awk -v m="§max" -v r="$floorRatio" 'BEGIN{printf "%d\n", m*r}')
  echo "POLICY=§p|§old|§floor|§max"
done
""".replace('§', '$')
        val probe = ShizukuBridge.sh(script, 5000L, "CPU_PERFORMANCE")
        val lines = probe.out.lines().filter { it.startsWith("POLICY=") }
        if (lines.isEmpty()) return Step(St.UNSUPPORTED, "no writable CPU frequency policy for shell user")

        var verified = 0
        for (line in lines) {
            val v = line.removePrefix("POLICY=").split('|')
            if (v.size < 4) continue
            val path = v[0]; val old = v[1]; val floor = v[2].toLongOrNull() ?: continue
            saveOnce(prefs, "cpu.min:$path", old)
            val w = ShizukuBridge.sh("echo $floor > $path/scaling_min_freq", 3000L, "CPU_PERFORMANCE")
            val now = ShizukuBridge.sh("cat $path/scaling_min_freq 2>/dev/null", 3000L, "CPU_PERFORMANCE").stdout.trim().toLongOrNull()
            if (w.ok && now != null && now >= floor) verified++
        }
        return if (verified == lines.size) {
            Caps.markVerified(Cap.CPU_PERFORMANCE)
            Step(St.VERIFIED, "CPU minimum frequency raised on $verified policies")
        } else if (verified > 0) Step(St.APPLIED, "CPU floor applied on $verified/${lines.size} policies")
        else Step(St.FAILED, "CPU performance controls were rejected")
    }

    fun releaseCpu(prefs: Prefs): List<String> = restoreKeys(prefs) { it == "cpu.fixed" || it.startsWith("cpu.min:") }

    // ------------------------------------------------------------------ GPU
    /** Picks a REAL frequency step the kernel lists. Nothing is hard-coded. level: 0 balanced, 1 performance, 2 maximum. */
    fun pickGpu(g: Sampler.GpuInfo, level: Int): Long? {
        val cap = if (g.maxF > 0) g.maxF else (g.avail.lastOrNull() ?: return null)
        val steps = g.avail.filter { it <= cap }.sorted()
        if (steps.isEmpty()) return null
        return when (level) {
            0 -> steps[steps.size / 2]
            1 -> steps[((steps.size * 3) / 4).coerceAtMost(steps.size - 1)]
            else -> steps[steps.size - 1]
        }
    }

    fun applyGpu(prefs: Prefs, g: Sampler.GpuInfo?, level: Int): GpuResult {
        if (g == null || !Caps.controllable(Cap.GPU_PERFORMANCE) || !g.writableMin) {
            return GpuResult(Step(St.UNSUPPORTED, Caps.reason(Cap.GPU_PERFORMANCE)), -1)
        }
        val pick = pickGpu(g, level) ?: return GpuResult(Step(St.FAILED, "no usable frequency step"), -1)
        saveOnce(prefs, "gpu.min", g.dir + "|" + g.minF)
        val w = ShizukuBridge.sh("echo $pick > ${g.dir}/min_freq", 3000L, "GPU_PERFORMANCE")
        val now = ShizukuBridge.sh("cat ${g.dir}/min_freq", 3000L, "GPU_PERFORMANCE").stdout.trim().toLongOrNull()
        val mhz = Sampler.rawToMhz(pick)
        return if (now == pick) GpuResult(Step(St.APPLIED, GPU_LEVELS[level.coerceIn(0, 2)] + ": floor " + mhz + " MHz written, waiting for the clock"), mhz)
        else GpuResult(Step(St.FAILED, "kernel refused the write" + (if (w.stderr.isNotEmpty()) " (" + w.stderr.take(40) + ")" else "")), -1)
    }

    fun releaseGpu(prefs: Prefs): List<String> = restoreKeys(prefs) { it == "gpu.min" }

    // ------------------------------------------------------------------ EFFECTS
    private fun sfMatrix(r: Float, g: Float, b: Float): String =
        "service call SurfaceFlinger 1015 i32 1 f $r f 0 f 0 f 0 f 0 f $g f 0 f 0 f 0 f 0 f $b f 0 f 0 f 0 f 0 f 1"

    /** fx: 0 COOL, 1 VIVID, 2 CINEMATIC, 3 PERFORMANCE, 4 DEFAULT. These change the DISPLAY pipeline, not the game's engine. */
    fun applyFx(prefs: Prefs, fx: Int): Step {
        if (fx >= 3) {
            restoreKeys(prefs) { it == "fx.sf" || it == "set:secure:display_color_mode" }
            return Step(St.APPLIED, if (fx == 4) "default colours" else "no colour processing")
        }
        if (!Caps.controllable(Cap.DISPLAY_COLOR)) return Step(St.UNSUPPORTED, Caps.reason(Cap.DISPLAY_COLOR))
        var verified = false
        var detail = ""
        if (fx != 0 && Detect.colorModeOk) {
            val mode = if (fx == 1) "1" else "0"
            if (putSetting(prefs, "secure", "display_color_mode", mode)) { verified = true; detail = "colour mode $mode" }
        }
        var sfDone = false
        if (Detect.sfColorOk) {
            val sat: Float
            val matrix: String
            when (fx) {
                0 -> { sat = 1.0f; matrix = sfMatrix(0.93f, 0.98f, 1.06f) }
                1 -> { sat = 1.4f; matrix = "service call SurfaceFlinger 1015 i32 0" }
                else -> { sat = 0.9f; matrix = sfMatrix(1.04f, 0.98f, 0.90f) }
            }
            saveOnce(prefs, "fx.sf", "1")
            val a = ShizukuBridge.sh("service call SurfaceFlinger 1022 f $sat 2>&1", 3000L, "DISPLAY_COLOR")
            val b = ShizukuBridge.sh("$matrix 2>&1", 3000L, "DISPLAY_COLOR")
            sfDone = okSf(a) && okSf(b)
        }
        return when {
            verified -> { Caps.markVerified(Cap.DISPLAY_COLOR); Step(St.VERIFIED, detail + (if (sfDone) " + colour transform" else "")) }
            sfDone -> Step(St.APPLIED, "SurfaceFlinger colour transform (Android gives no read-back)")
            else -> Step(St.FAILED, "this device rejected the colour change")
        }
    }

    // ------------------------------------------------------------------ TOUCH
    /** level: 0 FAST, 1 DEFAULT, 2 SLOW. Uses Android's touch-and-hold delay. It does NOT change raw touch latency. */
    fun applyTouch(prefs: Prefs, level: Int): Step {
        if (!Caps.controllable(Cap.TOUCH_RESPONSE)) return Step(St.UNSUPPORTED, Caps.reason(Cap.TOUCH_RESPONSE))
        if (level == 1) {
            val l = restoreKeys(prefs) { it == "set:secure:long_press_timeout" }
            return Step(St.APPLIED, if (l.isEmpty()) "system default" else "system default restored")
        }
        val ms = if (level == 0) 250 else 700
        return if (putSetting(prefs, "secure", "long_press_timeout", ms.toString())) {
            Caps.markVerified(Cap.TOUCH_RESPONSE)
            Step(St.VERIFIED, "touch-and-hold delay $ms ms (Android has no touch-latency control)")
        } else Step(St.FAILED, "system refused the setting")
    }

    // ------------------------------------------------------------------ DNS
    /** idx: 0 AUTO (system), 1 CLOUDFLARE, 2 GOOGLE, 3 QUAD9. DNS affects name lookups, not in-match ping. */
    fun applyDns(prefs: Prefs, idx: Int): Step {
        if (!Caps.controllable(Cap.DNS)) return Step(St.UNSUPPORTED, Caps.reason(Cap.DNS))
        if (idx <= 0) {
            val l = restoreKeys(prefs) { it == "set:global:private_dns_mode" || it == "set:global:private_dns_specifier" }
            return Step(St.APPLIED, if (l.isEmpty()) "system DNS" else "system DNS restored")
        }
        val host = DNS_HOSTS[idx.coerceIn(1, 3)]
        val a = putSetting(prefs, "global", "private_dns_specifier", host)
        val b = putSetting(prefs, "global", "private_dns_mode", "hostname")
        return if (a && b) { Caps.markVerified(Cap.DNS); Step(St.VERIFIED, "Private DNS $host (setting read back)") }
        else Step(St.FAILED, "system refused Private DNS")
    }

    // ------------------------------------------------------------------ BACKGROUND
    private val KEEP_WORDS = listOf("whatsapp", "telegram", "messenger", "signal", "discord", "spotify", "music", "maps", "waze", "authenticator", "banking", "shizuku")

    /** Asks Android to stop only safe background processes of user apps. Never force-stops and never touches system apps. */
    fun applyBackground(prefs: Prefs, gamePkg: String, selfPkg: String): Step {
        val third = ShizukuBridge.sh("pm list packages -3 2>/dev/null", 6000L, "BACKGROUND").stdout.lines()
            .filter { it.startsWith("package:") }.map { it.removePrefix("package:").trim() }
        if (third.isEmpty()) return Step(St.UNSUPPORTED, "cannot list user apps")
        val keep = HashSet<String>()
        keep.add(gamePkg); keep.add(selfPkg); keep.add(ShizukuBridge.PKG)
        for (g in com.sanju.systemx.game.ProfileStore.all()) keep.add(g.pkg)
        keep.addAll(prefs.getS("bg_whitelist", "").split(',').map { it.trim() }.filter { it.isNotEmpty() })
        val ime = ShizukuBridge.setting("secure", "default_input_method").substringBefore('/')
        keep.add(ime)
        ShizukuBridge.setting("secure", "enabled_accessibility_services").split(':').forEach { keep.add(it.substringBefore('/')) }
        keep.add(ShizukuBridge.setting("secure", "sms_default_application"))
        val home = ShizukuBridge.sh("cmd package resolve-activity --brief -a android.intent.action.MAIN -c android.intent.category.HOME 2>/dev/null", 4000L, "BACKGROUND")
            .stdout.lines().lastOrNull { it.contains('/') }?.trim()?.substringBefore('/')
        if (home != null) keep.add(home)
        fun running(): Set<String> {
            val names = ShizukuBridge.sh("ps -A -o NAME 2>/dev/null", 6000L, "BACKGROUND").stdout.lines().map { it.trim() }.filter { it.isNotEmpty() }
            return third.filter { p -> names.any { it == p || it.startsWith("$p:") } }.toSet()
        }
        val before = running()
        val targets = before.filter { p ->
            p !in keep && Regex("^[A-Za-z0-9._]+$").matches(p) && KEEP_WORDS.none { p.contains(it, true) }
        }.take(30)
        if (targets.isEmpty()) return Step(St.APPLIED, "nothing safe to stop")
        ShizukuBridge.sh(targets.joinToString("; ") { "am kill $it" }, 15000L, "BACKGROUND")
        val after = running()
        val stopped = targets.count { it !in after }
        return if (stopped > 0) Step(St.VERIFIED, "$stopped of ${targets.size} background apps stopped (they restart on demand)")
        else Step(St.APPLIED, "asked ${targets.size} apps to stop, Android kept them")
    }

    // ------------------------------------------------------------------ restore
    fun restore(prefs: Prefs): List<String> {
        val l = restoreKeys(prefs) { true }
        return if (l.isEmpty()) listOf("NOTHING TO RESTORE") else l
    }

    /** Restores every journal entry whose key matches. Entries that fail stay in the journal and are retried later. */
    fun restoreKeys(prefs: Prefs, match: (String) -> Boolean): List<String> {
        val j = load(prefs)
        val lines = ArrayList<String>()
        val remaining = LinkedHashMap<String, String>()
        for ((k, v) in j) {
            if (!match(k)) { remaining[k] = v; continue }
            val ok = when {
                k.startsWith("set:") -> {
                    val p = k.split(":", limit = 3)
                    p.size == 3 && restoreSetting(p[1], p[2], v)
                }
                k.startsWith("game.overlay:") -> {
                    val pkg = k.substringAfter(':')
                    val cmd = if (v == "null" || v.isBlank()) "device_config delete game_overlay $pkg" else "device_config put game_overlay $pkg '$v'"
                    ShizukuBridge.sh(cmd, 4000L, "GAME_MODE").ok
                }
                k.startsWith("game.mode.before:") -> restoreGameMode(k.substringAfter(':'), v)
                k.startsWith("game.mode:") -> restoreGameMode(k.substringAfter(':'), "standard")
                k == "game.mode" -> restoreGameMode(com.sanju.systemx.game.ProfileStore.MLBB, "standard")
                k == "sys.min_refresh_rate" -> restoreSetting("system", "min_refresh_rate", v)
                k == "sys.peak_refresh_rate" -> restoreSetting("system", "peak_refresh_rate", v)
                k == "gpu.min" -> {
                    val p = v.split('|')
                    p.size == 2 && (p[1].toLongOrNull() ?: 0L) > 0L &&
                        ShizukuBridge.sh("echo ${p[1]} > ${p[0]}/min_freq", 3000L, "GPU_PERFORMANCE").ok
                }
                k == "cpu.fixed" -> ShizukuBridge.sh("cmd power set-fixed-performance-mode-enabled false 2>&1", 4000L, "CPU_PERFORMANCE").ok
                k.startsWith("cpu.min:") -> {
                    val path = k.substringAfter(':')
                    ShizukuBridge.sh("echo $v > $path/scaling_min_freq", 3000L, "CPU_PERFORMANCE").ok
                }
                k == "fx.sf" -> {
                    val a = ShizukuBridge.sh("service call SurfaceFlinger 1022 f 1.0 2>&1", 3000L, "DISPLAY_COLOR")
                    val b = ShizukuBridge.sh("service call SurfaceFlinger 1015 i32 0 2>&1", 3000L, "DISPLAY_COLOR")
                    okSf(a) && okSf(b)
                }
                else -> true
            }
            if (ok) lines.add("RESTORED $k") else { remaining[k] = v; lines.add("RESTORE FAILED $k (will retry)") }
        }
        save(prefs, remaining)
        return lines
    }
}
