package com.sanju.systemx.monitor

import com.sanju.systemx.shizuku.ShizukuBridge
import com.sanju.systemx.shizuku.ShellResult
import java.util.Locale

/** One parsed sample of what the shell could read. Missing sections stay empty = unavailable. */
class Raw(
    val stat: String?,
    val freqs: List<Long>,
    val types: Map<String, String>,
    val temps: Map<String, Float>,
    val gpuF: String?,
    val gpuB: List<String>,
    val fps: List<String>,
    val fg: String?,
    val gfx: List<String>,
    val therm: String?,
    val complete: Boolean
)

object Sampler {
    const val PKG = "com.mobile.legends"

    // '§' stands for '$' so Kotlin does not treat it as a template. Args: §1=gpu dir, §2=SurfaceFlinger layer, §3=check foreground (1/0), §4=gfxinfo package (fallback FPS, may be empty), §5=read thermal status (1/0)
    private val FULL = """
G="§1"; L="§2"; FG="§3"; GP="§4"; TH="§5"
echo "@@STAT"; head -n 1 /proc/stat
echo "@@FREQ"; cat /sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_cur_freq 2>/dev/null
echo "@@TYPE"; grep -H '' /sys/class/thermal/thermal_zone*/type 2>/dev/null
echo "@@TEMP"; grep -H '' /sys/class/thermal/thermal_zone*/temp 2>/dev/null
echo "@@GPUF"; if [ -n "§G" ]; then cat "§G/cur_freq" 2>/dev/null; fi
echo "@@GPUB"; cat /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage 2>/dev/null; cat /sys/class/kgsl/kgsl-3d0/gpubusy 2>/dev/null; cat /sys/kernel/gpu/gpu_busy 2>/dev/null
echo "@@FPS"; if [ -n "§L" ]; then dumpsys SurfaceFlinger --latency "§L" 2>/dev/null; fi
echo "@@GFX"; if [ -n "§GP" ]; then dumpsys gfxinfo "§GP" framestats 2>/dev/null | sed -n '/---PROFILEDATA---/,/---PROFILEDATA---/p'; fi
echo "@@THERM"; if [ "§TH" = "1" ]; then dumpsys thermalservice 2>/dev/null | grep -m1 -i "Thermal Status"; fi
if [ "§FG" = "1" ]; then
  echo "@@FG"
  r=§(dumpsys activity activities 2>/dev/null | grep -m2 ResumedActivity)
  if [ -z "§r" ]; then r=§(dumpsys window 2>/dev/null | grep -m2 -E 'mCurrentFocus|mFocusedApp'); fi
  echo "§r"
fi
echo "@@END"
""".replace('§', '$')

    private val FG_ONLY = """
echo "@@FG"
r=§(dumpsys activity activities 2>/dev/null | grep -m2 ResumedActivity)
if [ -z "§r" ]; then r=§(dumpsys window 2>/dev/null | grep -m2 -E 'mCurrentFocus|mFocusedApp'); fi
echo "§r"
echo "@@END"
""".replace('§', '$')

    fun sampleFull(gpuDir: String, layer: String, checkFg: Boolean, gfxPkg: String = "", therm: Boolean = false): Raw? {
        val r = ShizukuBridge.exec(arrayOf("sh", "-c", FULL, "sx", gpuDir, layer, if (checkFg) "1" else "0", gfxPkg, if (therm) "1" else "0"), 8000L)
        return if (r.code == -2 || r.code == -3) null else parse(r.out)
    }

    fun sampleFg(): Raw? {
        val r = ShizukuBridge.exec(arrayOf("sh", "-c", FG_ONLY), 6000L)
        return if (r.code == -2 || r.code == -3) null else parse(r.out)
    }

    private fun zoneId(path: String): String {
        val i = path.indexOf("thermal_zone")
        if (i < 0) return path
        val rest = path.substring(i + 12)
        val j = rest.indexOf('/')
        return if (j > 0) rest.substring(0, j) else rest
    }

    fun parse(out: String): Raw {
        var sec = ""
        var stat: String? = null
        val freqs = ArrayList<Long>()
        val types = HashMap<String, String>()
        val temps = HashMap<String, Float>()
        var gpuF: String? = null
        val gpuB = ArrayList<String>()
        val fps = ArrayList<String>()
        val gfx = ArrayList<String>()
        var therm: String? = null
        val fg = StringBuilder()
        var fgSeen = false
        var end = false
        for (raw in out.lines()) {
            val line = raw.trim()
            if (line.startsWith("@@")) {
                sec = line.substring(2)
                if (sec == "FG") fgSeen = true
                if (sec == "END") end = true
                continue
            }
            if (line.isEmpty()) continue
            when (sec) {
                "STAT" -> { if (stat == null) stat = line }
                "FREQ" -> { val v = line.toLongOrNull(); if (v != null) freqs.add(v) }
                "TYPE" -> { val i = line.indexOf(':'); if (i > 0) types[zoneId(line.substring(0, i))] = line.substring(i + 1).trim() }
                "TEMP" -> {
                    val i = line.indexOf(':')
                    if (i > 0) {
                        val v = line.substring(i + 1).trim().toFloatOrNull()
                        if (v != null) temps[zoneId(line.substring(0, i))] = v
                    }
                }
                "GPUF" -> { if (gpuF == null) gpuF = line }
                "GPUB" -> { gpuB.add(line) }
                "FPS" -> { fps.add(line) }
                "GFX" -> { gfx.add(line) }
                "THERM" -> { if (therm == null) therm = line }
                "FG" -> { if (fg.isNotEmpty()) fg.append(' '); fg.append(line) }
            }
        }
        return Raw(stat, freqs, types, temps, gpuF, gpuB, fps, if (fgSeen) fg.toString() else null, gfx, therm, end)
    }

    /** Result of a one-time device probe. Everything is read from the device, nothing is assumed. */
    class GpuInfo(
        val dir: String, val writableMin: Boolean, val writableMax: Boolean,
        val avail: List<Long>, val minF: Long, val maxF: Long
    )

    fun probeGpu(): GpuInfo? {
        val script = """
for d in /sys/class/kgsl/kgsl-3d0/devfreq /sys/class/devfreq/* /sys/devices/platform/*/devfreq/* /sys/devices/platform/soc/*/devfreq/*; do
  [ -r "§d/cur_freq" ] || continue
  case "§d" in *kgsl*|*gpu*|*mali*|*GPU*|*Mali*) ;; *) continue ;; esac
  echo "DIR=§d"
  if [ -w "§d/min_freq" ]; then echo "WMIN=1"; fi
  if [ -w "§d/max_freq" ]; then echo "WMAX=1"; fi
  echo "AVAIL=§(cat "§d/available_frequencies" 2>/dev/null)"
  echo "MIN=§(cat "§d/min_freq" 2>/dev/null)"
  echo "MAX=§(cat "§d/max_freq" 2>/dev/null)"
  break
done
""".replace('§', '$')
        val r: ShellResult = ShizukuBridge.sh(script)
        var dir = ""
        var wmin = false
        var wmax = false
        var avail: List<Long> = emptyList()
        var minF = -1L
        var maxF = -1L
        for (l in r.out.lines()) {
            val i = l.indexOf('=')
            if (i <= 0) continue
            val k = l.substring(0, i)
            val v = l.substring(i + 1).trim()
            when (k) {
                "DIR" -> dir = v
                "WMIN" -> wmin = true
                "WMAX" -> wmax = true
                "AVAIL" -> avail = v.split(' ', '\t').mapNotNull { it.toLongOrNull() }.sorted()
                "MIN" -> minF = v.toLongOrNull() ?: -1L
                "MAX" -> maxF = v.toLongOrNull() ?: -1L
            }
        }
        return if (dir.isEmpty()) null else GpuInfo(dir, wmin, wmax, avail, minF, maxF)
    }

    fun rawToMhz(v: Long): Int = when {
        v >= 1_000_000L -> (v / 1_000_000L).toInt()
        v >= 1_000L -> (v / 1_000L).toInt()
        else -> v.toInt()
    }

    fun normTemp(v: Float): Float = if (v >= 1000f) v / 1000f else v

    fun isCpuZone(t: String): Boolean {
        val s = t.lowercase(Locale.US)
        return s.contains("cpu") || s.contains("cluster") || s == "big" || s == "mid" || s == "little"
    }

    fun isGpuZone(t: String): Boolean {
        val s = t.lowercase(Locale.US)
        return s.contains("gpu") || s.contains("kgsl") || s.contains("mali") || s == "g3d"
    }
}

/** Stateful calculations that need the previous sample. */
class Calc {
    private var pTotal = 0L
    private var pIdle = 0L
    private var havePrev = false
    private var lastFrameTs = 0L

    /** CPU usage percent from /proc/stat deltas, -1 if unavailable (first sample or unreadable). */
    fun cpu(stat: String?): Float {
        if (stat == null) return -1f
        val p = stat.trim().split(Regex("\\s+"))
        if (p.size < 5) return -1f
        var total = 0L
        for (i in 1 until minOf(p.size, 9)) total += p[i].toLongOrNull() ?: 0L
        val idle = (p[4].toLongOrNull() ?: 0L) + (if (p.size > 5) (p[5].toLongOrNull() ?: 0L) else 0L)
        val r: Float
        if (!havePrev) {
            r = -1f
        } else {
            val dT = total - pTotal
            val dI = idle - pIdle
            r = if (dT <= 0L) -1f else ((dT - dI).toFloat() * 100f / dT.toFloat()).coerceIn(0f, 100f)
        }
        pTotal = total
        pIdle = idle
        havePrev = true
        return r
    }

    fun resetCpu() { havePrev = false }

    class FrameStats(val fps: Float, val frameMs: Float, val low1: Float, val jank: Int)

    @Volatile var stats: FrameStats? = null

    /** FPS from SurfaceFlinger frame timestamps. -1 = no data, 0 = no new frames since last sample. */
    fun fps(lines: List<String>): Float {
        if (lines.size < 2) { stats = null; return -1f }
        val ts = ArrayList<Long>()
        for (i in 1 until lines.size) {
            val p = lines[i].trim().split(Regex("\\s+"))
            if (p.size >= 3) {
                val v = p[1].toLongOrNull() ?: continue
                if (v > 0L && v < Long.MAX_VALUE / 2) ts.add(v)
            }
        }
        return fromTs(ts)
    }

    /** Fallback FPS source: dumpsys gfxinfo framestats (FrameCompleted column). */
    fun fpsGfx(lines: List<String>): Float {
        var idx = -1
        val ts = ArrayList<Long>()
        for (l in lines) {
            val t = l.trim()
            if (t.isEmpty() || t.startsWith("---")) continue
            val c = t.split(',')
            if (idx < 0) { val i = c.indexOf("FrameCompleted"); if (i >= 0) idx = i; continue }
            val v = c.getOrNull(idx)?.trim()?.toLongOrNull() ?: continue
            if (v > 0L && v < Long.MAX_VALUE / 2) ts.add(v)
        }
        if (ts.isEmpty()) { stats = null; return -1f }
        return fromTs(ts)
    }

    private fun fromTs(ts: List<Long>): Float {
        val last = ts.maxOrNull() ?: return -1f
        if (last == lastFrameTs) return 0f
        lastFrameTs = last
        val sorted = ts.sorted()
        val win = sorted.filter { it > last - 1_000_000_000L }
        val d = ArrayList<Float>()
        for (i in 1 until sorted.size) {
            val ms = (sorted[i] - sorted[i - 1]) / 1_000_000f
            if (ms > 0f && ms < 1000f) d.add(ms)
        }
        val f: Float = if (win.size < 2) win.size.toFloat() else {
            val span = win[win.size - 1] - win[0]
            if (span <= 0L) -1f else (win.size - 1) * 1_000_000_000f / span
        }
        if (d.size >= 5) {
            val sd = d.sorted()
            val med = sd[sd.size / 2]
            val p99 = sd[((sd.size - 1) * 0.99f).toInt().coerceAtMost(sd.size - 1)]
            val jank = d.count { it > med * 1.5f && it > med + 8f }
            stats = FrameStats(f, d.average().toFloat(), if (p99 > 0f) 1000f / p99 else -1f, jank)
        } else {
            stats = FrameStats(f, -1f, -1f, 0)
        }
        return f
    }

    fun resetFps() { lastFrameTs = 0L }
}
