package com.sanju.systemx.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.sanju.systemx.caps.Caps
import com.sanju.systemx.device.Detect
import com.sanju.systemx.engine.Engine
import com.sanju.systemx.engine.WatcherService
import com.sanju.systemx.game.ProfileStore
import com.sanju.systemx.net.NetEngine
import com.sanju.systemx.optimizer.Applier
import com.sanju.systemx.optimizer.St
import com.sanju.systemx.optimizer.Step
import com.sanju.systemx.resolution.DisplayCtl
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.sfx.Sfx
import com.sanju.systemx.sfx.SfxHub
import com.sanju.systemx.shizuku.ShizukuBridge
import com.sanju.systemx.shizuku.ShizukuState
import java.util.Locale

/** A label with a wrapping status line underneath. Shows a Step in its honest colour. */
private class StepRow(ctx: Context, label: String) {
    val view = LinearLayout(ctx)
    private val value = ctx.tv("-", 12f, Pal.TEXT, true)
    init {
        view.orientation = LinearLayout.VERTICAL
        view.addView(ctx.tv(label, 10f, Pal.SUB))
        view.addView(value)
    }
    fun set(s: Step) {
        val t = s.text()
        if (value.text.toString() != t) value.text = t
        value.setTextColor(when (s.st) {
            St.VERIFIED, St.APPLIED -> Pal.GREEN
            St.REQUESTED, St.UNSUPPORTED -> Pal.AMBER
            St.FAILED -> Pal.RED
            St.NOT_REQUESTED -> Pal.SUB
        })
    }
}

/**
 * The landscape Game Space. The rail on the left switches between sections:
 * GAME, PERFORMANCE, DISPLAY, EFFECTS, NETWORK, TOUCH, MONITOR, SETTINGS.
 * Every control here writes a profile or preference that the Engine acts on. Reads Engine state 4x per second, only while visible.
 */
class Hud(private val a: Activity, private val prefs: Prefs) {
    val view = LinearLayout(a)

    private val shizukuChip = a.tv("SHIZUKU", 11f, Pal.TEXT, true)
    private val gameChip = a.tv("GAME", 11f, Pal.TEXT, true)
    private val pages = ArrayList<View>()
    private val navItems = ArrayList<TextView>()

    // GAME
    private val gName = Row(a, "SELECTED GAME")
    private val gState = Row(a, "STATE")
    private val autoBig = a.tv("-", 26f, Pal.TEXT, true)
    private val autoSub = a.tv("", 11f, Pal.SUB)
    private val logView = a.tv("", 10f, Pal.SUB)
    private val planRow = Row(a, "AUTO PLAN")
    // PERFORMANCE
    private val sGame = StepRow(a, "GAME MODE")
    private val sCpu = StepRow(a, "CPU PERFORMANCE")
    private val sGpu = StepRow(a, "GPU PERFORMANCE")
    private val sBg = StepRow(a, "BACKGROUND OPTIMIZATION")
    private val thermalGuardRow = Row(a, "THERMAL GUARD")
    private val cpuInfo = Row(a, "CPU")
    private val cpuUse = Row(a, "USAGE")
    private val cpuFreq = Row(a, "FREQUENCY (PEAK CORE)")
    private val cpuTemp = Row(a, "TEMPERATURE")
    private val gpuInfo = Row(a, "GPU")
    private val gpuUse = Row(a, "USAGE")
    private val gpuFreq = Row(a, "FREQUENCY")
    private val gpuTemp = Row(a, "TEMPERATURE")
    private val thermal = Row(a, "THERMAL STATE")
    private val battTemp = Row(a, "BATTERY TEMPERATURE")
    // DISPLAY
    private val hzActual = Row(a, "ACTUAL REFRESH RATE")
    private val hzTarget = Row(a, "TARGET (REQUESTED)")
    private val hzMax = Row(a, "PANEL MAXIMUM")
    private val hzMode = Row(a, "DISPLAY MODE")
    private val sDisplay = StepRow(a, "DISPLAY STATUS")
    private val fpsGoal = Row(a, "GAME FPS GOAL")
    private val hzModes = a.tv("", 10f, Pal.SUB)
    // EFFECTS / TOUCH / NETWORK
    private val sFx = StepRow(a, "EFFECT STATUS")
    private val fxCap = a.tv("", 10f, Pal.SUB)
    private val sTouch = StepRow(a, "TOUCH STATUS")
    private val sDns = StepRow(a, "DNS STATUS")
    private val nPing = Row(a, "PING")
    private val nJit = Row(a, "JITTER")
    private val nLoss = Row(a, "PACKET LOSS")
    private val nQual = Row(a, "NETWORK QUALITY")
    // MONITOR
    private val fpsBig = a.tv("--", 54f, Pal.TEXT, true)
    private val fpsSub = a.tv("", 10f, Pal.SUB)
    private val graph = GraphView(a)
    private val mAvg = Row(a, "AVERAGE FPS")
    private val mLow = Row(a, "1% LOW")
    private val mFrame = Row(a, "FRAME TIME")
    private val mJank = Row(a, "JANK / STUTTER")
    private val mHz = Row(a, "REFRESH RATE")
    private val mCpu = Row(a, "CPU")
    private val mGpu = Row(a, "GPU")
    private val mCpuT = Row(a, "CPU TEMP")
    private val mGpuT = Row(a, "GPU TEMP")
    private val mBatT = Row(a, "BATTERY TEMP")
    private val mPing = Row(a, "PING / JITTER / LOSS")
    // SETTINGS
    private val capText = a.tv("", 10f, Pal.SUB)

    private lateinit var perfSeg: Seg
    private lateinit var fxSeg: Seg
    private lateinit var dnsSeg: Seg
    private lateinit var touchSeg: Seg

    private var shownFps = 0f
    private var lastSeq = -1
    private var lastSel = ""
    private var lastCaps = ""
    private val need = "SHIZUKU REQUIRED"

    init {
        view.orientation = LinearLayout.VERTICAL
        view.setBackgroundColor(Pal.BG)
        view.setPadding(a.dp(14), a.dp(8), a.dp(14), a.dp(8))

        val top = LinearLayout(a)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val title = a.tv("SANJUSYSTEMX", 20f, Pal.RED, true)
        title.letterSpacing = 0.12f
        top.addView(title)
        top.addView(a.tv("  V3  GAME SPACE", 12f, Pal.TEXT, true))
        top.addView(View(a), LinearLayout.LayoutParams(0, 1, 1f))
        shizukuChip.setPadding(a.dp(10), a.dp(5), a.dp(10), a.dp(5))
        gameChip.setPadding(a.dp(10), a.dp(5), a.dp(10), a.dp(5))
        top.addView(shizukuChip)
        top.addView(gameChip, LinearLayout.LayoutParams(-2, -2).also { it.leftMargin = a.dp(8) })
        view.addView(top)

        val body = LinearLayout(a)
        body.orientation = LinearLayout.HORIZONTAL
        view.add(body, 8, 1f)
        body.addView(buildNav(listOf("GAME", "PERFORMANCE", "DISPLAY", "EFFECTS", "NETWORK", "TOUCH", "MONITOR", "SETTINGS")),
            LinearLayout.LayoutParams(a.dp(112), LinearLayout.LayoutParams.MATCH_PARENT))
        val content = FrameLayout(a)
        body.addView(content, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).also { it.leftMargin = a.dp(10) })

        pages.add(gamePage()); pages.add(performancePage()); pages.add(displayPage()); pages.add(effectsPage())
        pages.add(networkPage()); pages.add(touchPage()); pages.add(monitorPage()); pages.add(settingsPage())
        for (p in pages) content.addView(p, FrameLayout.LayoutParams(-1, -1))
        select(0, false)

        shizukuChip.setOnClickListener { onShizukuTap() }
        update()
    }

    // ---------------------------------------------------------------- navigation
    private fun buildNav(names: List<String>): View {
        val rail = LinearLayout(a)
        rail.orientation = LinearLayout.VERTICAL
        rail.background = a.bg(Pal.PANEL, 14, Pal.RED_DIM, 1)
        rail.setPadding(a.dp(6), a.dp(6), a.dp(6), a.dp(6))
        for ((i, n) in names.withIndex()) {
            val t = a.tv(n, 10f, Pal.SUB, true)
            t.gravity = Gravity.CENTER
            t.letterSpacing = 0.06f
            t.minHeight = a.dp(40)
            t.setOnClickListener { select(i, true) }
            navItems.add(t)
            rail.add(t, if (i == 0) 0 else 3)
        }
        val sc = ScrollView(a)
        sc.isVerticalScrollBarEnabled = false
        sc.addView(rail)
        return sc
    }

    private fun select(i: Int, sound: Boolean) {
        if (sound) SfxHub.play(Sfx.CLICK)
        for ((k, p) in pages.withIndex()) p.visibility = if (k == i) View.VISIBLE else View.GONE
        for ((k, t) in navItems.withIndex()) {
            val on = k == i
            t.background = a.bg(if (on) Pal.RED else Color.TRANSPARENT, 10)
            t.setTextColor(if (on) Pal.TEXT else Pal.SUB)
        }
    }

    private fun twoCol(left: List<View>, right: List<View>): ScrollView {
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        for ((ci, list) in listOf(left, right).withIndex()) {
            val col = LinearLayout(a)
            col.orientation = LinearLayout.VERTICAL
            for ((i, v) in list.withIndex()) col.add(v, if (i == 0) 0 else 8)
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            if (ci == 1) lp.leftMargin = a.dp(8)
            row.addView(col, lp)
        }
        val sc = ScrollView(a)
        sc.isVerticalScrollBarEnabled = false
        sc.addView(row, android.view.ViewGroup.LayoutParams(-1, -2))
        return sc
    }

    private fun note(t: String): TextView = a.tv(t, 10f, Pal.SUB)
    private fun sel() = ProfileStore.selected()
    private fun saveProfile() { ProfileStore.save(prefs) }

    // ---------------------------------------------------------------- pages
    /** GAME: selected game, launch, SANJU AUTO. Backend: ProfileStore + Engine.applyNow/restoreNow. */
    private fun gamePage(): View {
        val g = a.panel("GAME")
        g.add(gName.view, 6); g.add(gState.view, 4)
        g.add(Tog(a, "Auto-optimize this game", sel().autoOptimize) { sel().autoOptimize = it; saveProfile() }.view, 8)
        g.add(Tog(a, "Restore when the game exits", sel().restoreOnExit) { sel().restoreOnExit = it; saveProfile() }.view, 6)
        g.add(a.button("LAUNCH GAME", true) { launchGame() }, 10)
        g.add(a.button("SWITCH GAME", false) { ProfileStore.cycleSelected(prefs); SfxHub.play(Sfx.CLICK); update() }, 6)
        g.add(a.button("ADD GAME", false) { addGame() }, 6)

        val auto = a.panel("SANJU AUTO GAME MODE")
        auto.add(autoBig, 6); auto.add(autoSub, 2)
        auto.add(Tog(a, "SANJU AUTO", prefs.getB("auto_mode", true)) { prefs.setB("auto_mode", it); Engine.kick() }.view, 8)
        auto.add(a.tv("PERFORMANCE MODE (this game)", 10f, Pal.SUB), 8)
        perfSeg = Seg(a, listOf("OFF", "BALANCED", "PERFORMANCE"), sel().perfMode) {
            sel().perfMode = it; saveProfile()
            SfxHub.play(if (it == 2) Sfx.BOOST_ON else Sfx.CLICK)
            Engine.profileChanged()
        }
        auto.add(perfSeg.view, 3)
        auto.add(planRow.view, 8)
        auto.add(a.button("APPLY NOW", true) { Engine.applyNow() }, 8)
        auto.add(a.button("RESTORE", false) { Engine.restoreNow() }, 6)

        val log = a.panel("ACTIVITY")
        log.add(logView, 4)
        return twoCol(listOf(g), listOf(auto, log))
    }

    /** PERFORMANCE: Game Mode, CPU performance, GPU performance, background optimisation, thermal. */
    private fun performancePage(): View {
        val ap = a.panel("AUTO PERFORMANCE")
        ap.add(sGame.view, 6); ap.add(sCpu.view, 6); ap.add(sGpu.view, 6); ap.add(sBg.view, 6)
        ap.add(a.tv("GPU CEILING (AUTO never goes above this)", 10f, Pal.SUB), 10)
        ap.add(Seg(a, listOf("BALANCED", "PERFORMANCE", "MAXIMUM"), prefs.getI("gpu_level", 2)) {
            prefs.setI("gpu_level", it); Engine.profileChanged()
        }.view, 3)
        ap.add(a.tv("GAME RENDER SCALE (lower = more GPU headroom)", 10f, Pal.SUB), 10)
        ap.add(Seg(a, listOf("100%", "90%", "85%"), when (prefs.getI("render_scale", 90)) { 100 -> 0; 85 -> 2; else -> 1 }) {
            prefs.setI("render_scale", when (it) { 0 -> 100; 2 -> 85; else -> 90 }); Engine.profileChanged()
        }.view, 3)
        ap.add(note("Android Game Mode can lower only the game's render workload. This does not lower the phone's display resolution. Sanju verifies the Game Mode intervention before calling it verified."), 5)
        ap.add(Tog(a, "Background optimization (safe, no force-stop)", prefs.getB("bg_trim", true)) {
            prefs.setB("bg_trim", it); Engine.profileChanged()
        }.view, 10)
        ap.add(note("Only user apps with safe background processes are asked to stop. Keyboard, launcher, accessibility, messaging and music apps are protected."), 4)
        ap.add(Tog(a, "Thermal Guard (app policy; Android safety remains ON)", prefs.getB("thermal_guard", true)) {
            prefs.setB("thermal_guard", it); Engine.kick()
        }.view, 10)

        val cpu = a.panel("CPU")
        cpu.add(cpuInfo.view, 4); cpu.add(cpuUse.view, 3); cpu.add(cpuFreq.view, 3); cpu.add(cpuTemp.view, 3)
        val gpu = a.panel("GPU")
        gpu.add(gpuInfo.view, 4); gpu.add(gpuUse.view, 3); gpu.add(gpuFreq.view, 3); gpu.add(gpuTemp.view, 3)
        val th = a.panel("THERMAL")
        th.add(thermal.view, 4); th.add(battTemp.view, 3); th.add(thermalGuardRow.view, 4)
        th.add(note("Thermal Guard controls Sanju's adaptive boost policy. OFF does NOT disable Android/kernel thermal protection."), 6)
        return twoCol(listOf(ap), listOf(cpu, gpu, th))
    }

    /** DISPLAY: real refresh rate, request, verification. */
    private fun displayPage(): View {
        val d = a.panel("DISPLAY")
        d.add(hzActual.view, 6); d.add(hzTarget.view, 4); d.add(hzMax.view, 4); d.add(hzMode.view, 4)
        d.add(sDisplay.view, 8); d.add(fpsGoal.view, 8)
        val n = a.panel("SUPPORTED MODES")
        n.add(hzModes, 6)
        n.add(note("REQUESTED means Android accepted the setting. VERIFIED means the panel really switched. A phone that ignores the request is reported as FAILED. A 60 Hz panel is never reported as 120 Hz."), 8)
        n.add(note("The FPS target follows the selected real panel ceiling: 60/90/120 FPS. The target is a request only; the Monitor shows what the game really renders."), 8)
        return twoCol(listOf(d), listOf(n))
    }

    /** EFFECTS: COOL / VIVID / CINEMATIC / PERFORMANCE / DEFAULT via display colour controls. */
    private fun effectsPage(): View {
        val e = a.panel("GAME EFFECTS")
        fxSeg = Seg(a, Applier.EFFECTS, sel().effect) { sel().effect = it; saveProfile(); Engine.profileChanged() }
        e.add(fxSeg.view, 6)
        e.add(sFx.view, 10)
        val n = a.panel("ABOUT EFFECTS")
        n.add(fxCap, 6)
        n.add(note("Effects change the phone's display colour pipeline while the game runs. They do not modify the game's own graphics engine. Selected effects are applied when the game starts, or with APPLY NOW."), 8)
        return twoCol(listOf(e), listOf(n))
    }

    /** NETWORK: DNS profile plus real ping / jitter / packet loss. */
    private fun networkPage(): View {
        val dn = a.panel("DNS PROFILE")
        dnsSeg = Seg(a, Applier.DNS_NAMES, sel().dns) { sel().dns = it; saveProfile(); Engine.profileChanged() }
        dn.add(dnsSeg.view, 6)
        dn.add(sDns.view, 10)
        dn.add(note("DNS only changes how names are looked up. It does not lower in-match server ping."), 8)
        val m = a.panel("NETWORK MONITOR")
        m.add(nPing.view, 6); m.add(nJit.view, 4); m.add(nLoss.view, 4); m.add(nQual.view, 4)
        m.add(note("Measured with real pings to a public server. This is your route to the internet, not the game server."), 8)
        return twoCol(listOf(dn), listOf(m))
    }

    /** TOUCH: FAST / DEFAULT / SLOW via Android's touch-and-hold delay. */
    private fun touchPage(): View {
        val t = a.panel("TOUCH RESPONSE")
        touchSeg = Seg(a, Applier.TOUCH_NAMES, sel().touch) { sel().touch = it; saveProfile(); Engine.profileChanged() }
        t.add(touchSeg.view, 6)
        t.add(sTouch.view, 10)
        val n = a.panel("ABOUT TOUCH")
        n.add(note("Android exposes no raw touch-latency control. FAST and SLOW change the touch-and-hold delay (250 ms / 700 ms) and the value is read back to verify it. DEFAULT restores your own value."), 6)
        return twoCol(listOf(t), listOf(n))
    }

    /** MONITOR: real measurements only. "--" means not measurable right now. */
    private fun monitorPage(): View {
        fpsBig.gravity = Gravity.CENTER
        val f = a.panel("FPS")
        f.add(a.tv("ACTUAL FPS", 10f, Pal.SUB), 2); f.add(fpsBig); f.add(fpsSub, 2)
        f.add(graph, 6, h = a.dp(100))
        f.add(mAvg.view, 6); f.add(mLow.view, 3); f.add(mFrame.view, 3); f.add(mJank.view, 3)
        val s = a.panel("SYSTEM")
        s.add(mHz.view, 4); s.add(mCpu.view, 3); s.add(mGpu.view, 3)
        s.add(mCpuT.view, 3); s.add(mGpuT.view, 3); s.add(mBatT.view, 3); s.add(mPing.view, 3)
        return twoCol(listOf(f), listOf(s))
    }

    private fun settingsPage(): View {
        val st = a.panel("SYSTEM")
        st.add(Tog(a, "SOUND EFFECTS", prefs.getB("sfx_on", true)) { prefs.setB("sfx_on", it) }.view, 6)
        st.add(Tog(a, "Haptic feedback", prefs.getB("haptic", true)) { prefs.setB("haptic", it); Pal.haptic = it }.view, 8)
        st.add(Tog(a, "Background watcher (notification)", prefs.getB("watcher", true)) {
            prefs.setB("watcher", it)
            if (it) startWatcher() else a.stopService(Intent(a, WatcherService::class.java))
        }.view, 8)
        val v0 = prefs.getF("sfx_vol", 0.7f)
        val levels = floatArrayOf(0.35f, 0.7f, 1.0f)
        st.add(a.tv("SOUND VOLUME", 10f, Pal.SUB), 10)
        st.add(Seg(a, listOf("LOW", "MEDIUM", "HIGH"), if (v0 < 0.5f) 0 else if (v0 < 0.85f) 1 else 2) {
            prefs.setF("sfx_vol", levels[it]); SfxHub.play(Sfx.SUCCESS)
        }.view, 3)
        st.add(a.button("RE-DETECT DEVICE", false) { Engine.redetect(); SfxHub.play(Sfx.CLICK) }, 10)
        val c = a.panel("DETECTED CAPABILITIES")
        c.add(capText, 6)
        return twoCol(listOf(st), listOf(c))
    }

    // ---------------------------------------------------------------- actions
    fun startWatcher() {
        try { a.startForegroundService(Intent(a, WatcherService::class.java)) } catch (t: Throwable) { Engine.log("Could not start watcher: " + (t.message ?: "")) }
    }

    private fun launchGame() {
        val p = sel()
        val i = a.packageManager.getLaunchIntentForPackage(p.pkg)
        if (i == null) {
            SfxHub.play(Sfx.WARNING)
            Toast.makeText(a, p.name + " is not installed", Toast.LENGTH_SHORT).show()
        } else {
            SfxHub.play(Sfx.GAME_LAUNCH)
            a.startActivity(i)
        }
    }

    private fun addGame() {
        val pm = a.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != a.packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase(Locale.US) }
        if (apps.isEmpty()) { SfxHub.play(Sfx.WARNING); Toast.makeText(a, "No launchable apps found", Toast.LENGTH_SHORT).show(); return }
        android.app.AlertDialog.Builder(a)
            .setTitle("ADD GAME")
            .setItems(apps.map { it.second }.toTypedArray()) { _, w ->
                ProfileStore.add(prefs, apps[w].first, apps[w].second)
                SfxHub.play(Sfx.SUCCESS)
                Engine.kick()
                update()
            }
            .show()
    }

    private fun onShizukuTap() {
        when (Engine.shizuku) {
            ShizukuState.PERMISSION_REQUIRED -> ShizukuBridge.requestPermission()
            ShizukuState.DISCONNECTED -> {
                val i = a.packageManager.getLaunchIntentForPackage(ShizukuBridge.PKG)
                if (i != null) a.startActivity(i)
                else { SfxHub.play(Sfx.WARNING); Toast.makeText(a, "Install and start Shizuku first", Toast.LENGTH_LONG).show() }
            }
            else -> Engine.kick()
        }
    }

    private fun chip(t: TextView, text: String, color: Int) {
        t.text = text
        t.background = a.bg(Color.argb(60, Color.red(color), Color.green(color), Color.blue(color)), 8, color, 1)
        t.setTextColor(color)
    }

    private fun num(v: Float, fmt: String, unit: String): String =
        if (v >= 0f) String.format(Locale.US, fmt, v) + unit else "--"

    // ---------------------------------------------------------------- refresh
    fun update() {
        val s = Engine.shizuku
        val ok = s == ShizukuState.CONNECTED
        when (s) {
            ShizukuState.CONNECTED -> chip(shizukuChip, "SHIZUKU  CONNECTED", Pal.GREEN)
            ShizukuState.PERMISSION_REQUIRED -> chip(shizukuChip, "SHIZUKU  PERMISSION REQUIRED (TAP)", Pal.AMBER)
            ShizukuState.UNSUPPORTED -> chip(shizukuChip, "SHIZUKU  UNSUPPORTED", Pal.RED)
            ShizukuState.DISCONNECTED -> chip(shizukuChip, "SHIZUKU  DISCONNECTED (TAP)", Pal.RED)
        }
        val ag = Engine.activeGame
        if (!ok) chip(gameChip, "GAME  $need", Pal.AMBER)
        else if (!Engine.fgKnown) chip(gameChip, "GAME  DETECTION UNAVAILABLE", Pal.AMBER)
        else if (Engine.gameFg && ag != null) chip(gameChip, "GAME  " + ag.name.uppercase(Locale.US), Pal.GREEN)
        else chip(gameChip, "GAME  IDLE", Pal.SUB)

        val p = sel()
        if (lastSel != p.pkg) {
            lastSel = p.pkg
            perfSeg.select(p.perfMode); fxSeg.select(p.effect); dnsSeg.select(p.dns); touchSeg.select(p.touch)
        }

        // GAME
        gName.set(p.name)
        gState.set(if (!ok) need else if (Engine.gameFg) "DETECTED" + (if (Engine.coreOptimized) " · OPTIMIZED" else "") else "WAITING FOR GAME", if (Engine.gameFg) Pal.GREEN else Pal.SUB)
        val autoOn = prefs.getB("auto_mode", true)
        val big: String
        var bigCol = Pal.SUB
        if (!ok) { big = need; bigCol = Pal.AMBER }
        else if (!autoOn) big = "OFF"
        else if (Engine.coreOptimized) { big = "BOOST ACTIVE"; bigCol = Pal.GREEN }
        else if (Engine.gameFg) { big = "STARTING"; bigCol = Pal.AMBER }
        else big = "STANDBY"
        autoBig.text = big; autoBig.setTextColor(bigCol)
        autoSub.text = if (Engine.coreOptimized) "Optimized by " + Engine.appliedBy + " · thermal " + Engine.THERMAL_NAMES[Engine.thermalLevel]
            else if (ok && autoOn) "Optimizes automatically when a configured game opens" else ""
        planRow.set(if (Engine.maxHz > 0) "panel " + Engine.maxHz + " Hz -> about " + Engine.targetFps + " FPS" else "--")
        logView.text = Engine.logTail(6).joinToString("\n")

        // PERFORMANCE
        sGame.set(Engine.step("GAMEMODE")); sCpu.set(Engine.step("CPU")); sGpu.set(Engine.step("GPU")); sBg.set(Engine.step("BG"))
        val dev = Detect.info
        cpuInfo.set(if (dev != null) dev.cpuLine else "--")
        gpuInfo.set(if (dev != null) dev.gpuVendor else "--")
        cpuUse.set(if (!ok) need else num(Engine.cpuPct, "%.0f", " %"))
        cpuFreq.set(if (!ok) need else if (Engine.cpuMhz > 0) Engine.cpuMhz.toString() + " MHz" else "--")
        cpuTemp.set(if (!ok) need else num(Engine.cpuTemp, "%.1f", " C"))
        gpuUse.set(if (!ok) need else num(Engine.gpuPct, "%.0f", " %"))
        gpuFreq.set(if (!ok) need else if (Engine.gpuMhz > 0) Engine.gpuMhz.toString() + " MHz" else "--")
        gpuTemp.set(if (!ok) need else num(Engine.gpuTemp, "%.1f", " C"))
        battTemp.set(num(Engine.battTemp, "%.1f", " C"))
        val tl = Engine.thermalLevel
        thermalGuardRow.set(if (prefs.getB("thermal_guard", true)) "ON · adaptive cooling" else "OFF · Android safety still active")
        thermal.set(Engine.THERMAL_NAMES[tl], when (tl) { 0 -> Pal.SUB; 1 -> Pal.GREEN; 2 -> Pal.AMBER; else -> Pal.RED })

        // DISPLAY
        val cur = if (Engine.hzActual > 0f) Engine.hzActual else DisplayCtl.current(a)
        hzActual.set(if (cur > 0f) Math.round(cur).toString() + " Hz" else "--")
        hzTarget.set(if (Engine.hzReq > 0) Engine.hzReq.toString() + " Hz" else "--")
        val mx = DisplayCtl.maxRate(a)
        hzMax.set(if (mx > 0) "$mx Hz" else "--")
        hzMode.set(DisplayCtl.describe(a))
        sDisplay.set(Engine.step("DISPLAY"))
        fpsGoal.set(if (Engine.targetFps > 0) "about " + Engine.targetFps + " FPS" else "--")
        hzModes.text = DisplayCtl.modesText(a)

        // EFFECTS / TOUCH / NETWORK
        sFx.set(Engine.step("FX")); sTouch.set(Engine.step("TOUCH")); sDns.set(Engine.step("DNS"))
        fxCap.text = "DISPLAY COLOUR CONTROL: " + (if (!Caps.supported("DISPLAY_COLOR")) "NOT AVAILABLE. " else "") + Caps.reason("DISPLAY_COLOR")
        nPing.set(num(NetEngine.pingMs, "%.0f", " ms"))
        nJit.set(num(NetEngine.jitterMs, "%.1f", " ms"))
        nLoss.set(num(NetEngine.lossPct, "%.0f", " %"))
        nQual.set(NetEngine.quality, if (NetEngine.quality == "EXCELLENT" || NetEngine.quality == "GOOD") Pal.GREEN else if (NetEngine.quality == "--") Pal.SUB else Pal.AMBER)

        // MONITOR
        val fps = Engine.fps
        if (fps >= 0f) { shownFps += (fps - shownFps) * 0.4f; fpsBig.text = Math.round(shownFps).toString() }
        else { shownFps = 0f; fpsBig.text = "--" }
        fpsSub.text = if (!ok) need else if (!Engine.gameFg) "No game running" else if (fps < 0f) (if (Engine.fpsNote.isNotEmpty()) Engine.fpsNote else "UNAVAILABLE")
            else "source " + Engine.fpsSource + (if (Engine.fpsNote.isNotEmpty()) " · " + Engine.fpsNote else "")
        graph.target = if (Engine.targetFps > 0) Engine.targetFps.toFloat() else 60f
        if (Engine.sampleSeq != lastSeq) { lastSeq = Engine.sampleSeq; graph.push(if (Engine.gameFg) Engine.fps else -1f) }
        mAvg.set(num(Engine.fpsAvg, "%.0f", " FPS"))
        mLow.set(num(Engine.fps1Low, "%.0f", " FPS"))
        mFrame.set(num(Engine.frameMs, "%.1f", " ms"))
        mJank.set(if (Engine.jank >= 0) Engine.jank.toString() + " frames" else "--")
        mHz.set(if (cur > 0f) Math.round(cur).toString() + " Hz" else "--")
        mCpu.set(num(Engine.cpuPct, "%.0f", " %") + "  ·  " + (if (Engine.cpuMhz > 0) Engine.cpuMhz.toString() + " MHz" else "--"))
        mGpu.set(num(Engine.gpuPct, "%.0f", " %") + "  ·  " + (if (Engine.gpuMhz > 0) Engine.gpuMhz.toString() + " MHz" else "--"))
        mCpuT.set(num(Engine.cpuTemp, "%.1f", " C")); mGpuT.set(num(Engine.gpuTemp, "%.1f", " C")); mBatT.set(num(Engine.battTemp, "%.1f", " C"))
        mPing.set(num(NetEngine.pingMs, "%.0f", " ms") + " / " + num(NetEngine.jitterMs, "%.1f", " ms") + " / " + num(NetEngine.lossPct, "%.0f", " %"))

        // SETTINGS: capability list, rebuilt only when it changes
        val ct = Caps.all().joinToString("\n") {
            it.name + "  " + (if (it.supported) "SUPPORTED" else "NOT AVAILABLE") +
                (if (it.controllable) " · CONTROLLABLE" else "") + (if (it.verified) " · VERIFIED" else "") + "\n    " + it.reason + " (" + it.backend + ")"
        }.ifEmpty { "Detection runs once Shizuku is connected." }
        if (ct != lastCaps) { lastCaps = ct; capText.text = ct }
    }
}
