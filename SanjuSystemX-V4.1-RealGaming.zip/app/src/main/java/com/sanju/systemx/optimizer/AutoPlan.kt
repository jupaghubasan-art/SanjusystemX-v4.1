package com.sanju.systemx.optimizer

import android.content.Context
import com.sanju.systemx.resolution.DisplayCtl

/**
 * SANJU AUTO decision. The panel's real capability decides the target:
 * 60/90/120 Hz -> request the highest real panel mode; FPS target is the same ceiling, only a goal.
 * The target is only a goal. The Monitor shows what the game really renders.
 */
object AutoPlan {
    class Plan(val maxHz: Int, val reqHz: Int, val targetFps: Int, val note: String)

    fun targetFor(maxHz: Int): Int = when { maxHz >= 120 -> 120; maxHz >= 90 -> 90; maxHz >= 60 -> 60; else -> 0 }

    /** perfMode: 1 BALANCED, 2 PERFORMANCE. */
    fun compute(ctx: Context, perfMode: Int): Plan {
        val rates = DisplayCtl.ratesAtCurrentRes(ctx)
        if (rates.isEmpty()) return Plan(-1, -1, 0, "Display modes are unreadable")
        val max = rates.last()
        val target = targetFor(max)
        val req = if (perfMode >= 1) max else rates.first()
        return Plan(max, req, target, "Panel max $max Hz -> request $req Hz, game target $target FPS (target only; actual FPS is measured)")
    }
}
