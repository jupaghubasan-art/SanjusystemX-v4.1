package com.sanju.systemx.net

import com.sanju.systemx.caps.Cap
import com.sanju.systemx.caps.Capability
import com.sanju.systemx.caps.Caps
import com.sanju.systemx.shizuku.ShizukuBridge

/**
 * Real network measurement through the shell's ping (no fake numbers). Targets are public anycast IPs,
 * so this measures the route to the internet, NOT the game server and NOT DNS speed.
 */
object NetEngine {
    @Volatile var pingMs = -1f
    @Volatile var jitterMs = -1f
    @Volatile var lossPct = -1f
    @Volatile var host = ""
    @Volatile var quality = "--"
    @Volatile var failReason = ""

    private val HOSTS = listOf("1.1.1.1", "8.8.8.8")

    /** One measurement (about 2 seconds). Call from a background thread. */
    fun measure() {
        for (h in HOSTS) {
            val r = ShizukuBridge.sh("ping -c 5 -i 0.3 -W 1 $h 2>&1", 10000L, "PING")
            val out = r.stdout + "\n" + r.stderr
            val loss = Regex("""(\d+(?:\.\d+)?)% packet loss""").find(out)?.groupValues?.get(1)?.toFloatOrNull()
            val rtt = Regex("""=\s*([\d.]+)/([\d.]+)/([\d.]+)/([\d.]+)""").find(out)
            if (loss == null) {
                failReason = if (r.errorReason.isNotEmpty()) r.errorReason else "ping output not understood"
                continue
            }
            host = h
            lossPct = loss
            if (rtt != null && loss < 100f) {
                pingMs = rtt.groupValues[2].toFloatOrNull() ?: -1f
                jitterMs = rtt.groupValues[4].toFloatOrNull() ?: -1f
                quality = classify(pingMs, jitterMs, loss)
                failReason = ""
                Caps.put(Capability(Cap.PING, true, false, true, "Measured via ping to $h", "shell ping"))
                return
            }
            pingMs = -1f; jitterMs = -1f
            quality = if (loss >= 100f) "NO REPLY" else "--"
            failReason = "no replies from $h"
        }
        Caps.put(Capability(Cap.PING, false, false, false, failReason.ifEmpty { "ping unavailable" }, "shell ping"))
    }

    private fun classify(p: Float, j: Float, l: Float): String = when {
        l >= 5f || p >= 200f -> "POOR"
        l >= 3f || p >= 100f || j >= 30f -> "FAIR"
        l >= 1f || p >= 50f || j >= 10f -> "GOOD"
        else -> "EXCELLENT"
    }

    fun reset() { pingMs = -1f; jitterMs = -1f; lossPct = -1f; quality = "--"; host = "" }
}
