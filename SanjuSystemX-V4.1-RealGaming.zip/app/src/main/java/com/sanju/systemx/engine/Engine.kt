package com.sanju.systemx.engine

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Handler
import android.os.HandlerThread
import com.sanju.systemx.caps.Cap
import com.sanju.systemx.caps.Capability
import com.sanju.systemx.caps.Caps
import com.sanju.systemx.device.Detect
import com.sanju.systemx.game.GameProfile
import com.sanju.systemx.game.ProfileStore
import com.sanju.systemx.monitor.Calc
import com.sanju.systemx.monitor.Raw
import com.sanju.systemx.monitor.Sampler
import com.sanju.systemx.net.NetEngine
import com.sanju.systemx.optimizer.Applier
import com.sanju.systemx.optimizer.AutoPlan
import com.sanju.systemx.optimizer.St
import com.sanju.systemx.optimizer.Step
import com.sanju.systemx.resolution.DisplayCtl
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.sfx.Sfx
import com.sanju.systemx.shizuku.ShizukuBridge
import com.sanju.systemx.shizuku.ShizukuState
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * SANJU AUTO engine. Flow: DETECT -> APPLY -> VERIFY -> MONITOR -> ADJUST -> RESTORE.
 * All work happens on one background thread (plus one for ping). The UI only reads the @Volatile fields.
 * A metric that cannot be read stays at -1 and the UI shows "--" or UNAVAILABLE. Nothing is invented.
 */
object Engine {
    val THERMAL_NAMES = listOf("NORMAL", "PERFORMANCE", "THERMAL WARNING", "THERMAL PROTECTION")

    private var app: Context? = null
    private var prefs: Prefs? = null
    private var ht: HandlerThread? = null
    private var h: Handler? = null
    private var netHt: HandlerThread? = null
    private var netH: Handler? = null
    private val calc = Calc()

    @Volatile var uiVisible = false
    @Volatile var watcherActive = false
    @Volatile private var screenOn = true

    // ---- state read by the UI ----
    @Volatile var shizuku = ShizukuState.DISCONNECTED
    @Volatile var detected = false
    @Volatile var gameFg = false
    @Volatile var fgKnown = true
    @Volatile var activeGame: GameProfile? = null
    @Volatile var fps = -1f
    @Volatile var fpsAvg = -1f
    @Volatile var fps1Low = -1f
    @Volatile var frameMs = -1f
    @Volatile var jank = -1
    @Volatile var fpsSource = ""
    @Volatile var fpsNote = ""
    @Volatile var hzActual = -1f
    @Volatile var hzReq = 0
    @Volatile var maxHz = -1
    @Volatile var targetFps = 0
    @Volatile var cpuPct = -1f
    @Volatile var cpuMhz = -1
    @Volatile var cpuTemp = -1f
    @Volatile var gpuPct = -1f
    @Volatile var gpuMhz = -1
    @Volatile var gpuTemp = -1f
    @Volatile var battTemp = -1f
    @Volatile var thermalLevel = 0
    @Volatile var applied = false
    @Volatile var coreOptimized = false
    @Volatile var appliedBy = ""
    @Volatile var sampleSeq = 0
    val steps = ConcurrentHashMap<String, Step>()

    fun step(name: String): Step = steps[name] ?: Step.NONE

    private var gpu: Sampler.GpuInfo? = null
    private var layers: List<String> = emptyList()
    private var layerIdx = 0
    private var layerAt = 0L
    private var zeroFps = 0
    private var fpsMiss = 0
    private var miss = 0
    private var fgBlank = 0
    private var cycle = 0L
    private var recoveryDone = false
    private var thermalStatus = -1
    private var coolTicks = 0
    private var gpuCfg = -2
    private var gpuLevelApplied = -2
    private var gpuFloorMhz = -1
    private var gpuApplyAt = 0L
    private var cpuReleased = false
    private var hzChecks = 0
    private var fpsCapSet = false
    private val fpsHist = ArrayDeque<Float>()
    private val logBuf = ArrayList<String>()
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val sfxQ = ConcurrentLinkedQueue<Sfx>()

    private val screenRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            when (i?.action) {
                Intent.ACTION_SCREEN_OFF -> h?.post {
                    screenOn = false
                    if (applied) doRestore("SCREEN OFF")
                    gameFg = false
                    activeGame = null
                    fps = -1f
                }
                Intent.ACTION_SCREEN_ON -> { screenOn = true; kick() }
            }
        }
    }

    fun init(ctx: Context) {
        if (h != null) return
        app = ctx.applicationContext
        prefs = Prefs.get(ctx)
        ProfileStore.load(prefs!!)
        val t = HandlerThread("sx-engine")
        t.start()
        ht = t
        h = Handler(t.looper)
        val nt = HandlerThread("sx-net")
        nt.start()
        netHt = nt
        netH = Handler(nt.looper)
        try {
            val f = IntentFilter()
            f.addAction(Intent.ACTION_SCREEN_OFF)
            f.addAction(Intent.ACTION_SCREEN_ON)
            app!!.registerReceiver(screenRx, f)
        } catch (e: Throwable) { }
        ShizukuBridge.onChange = { why -> onShizukuChange(why) }
        ShizukuBridge.start()
        log("ENGINE STARTED")
        netH?.post(netRun)
        kick()
    }

    private val tickRun = object : Runnable {
        override fun run() {
            val next = try { tick() } catch (t: Throwable) { log("ENGINE ERROR: " + (t.message ?: t.javaClass.simpleName)); 3000L }
            h?.postDelayed(this, next)
        }
    }

    private val netRun = object : Runnable {
        override fun run() {
            var next = 8000L
            try {
                if (shizuku == ShizukuState.CONNECTED && screenOn && (uiVisible || gameFg)) {
                    NetEngine.measure()
                    next = 6000L
                }
            } catch (t: Throwable) { }
            netH?.postDelayed(this, next)
        }
    }

    /** Run a tick as soon as possible. */
    fun kick() {
        val hh = h ?: return
        hh.removeCallbacks(tickRun)
        hh.post(tickRun)
    }

    fun log(msg: String) {
        synchronized(logBuf) {
            logBuf.add(timeFmt.format(Date()) + "  " + msg)
            while (logBuf.size > 60) logBuf.removeAt(0)
        }
    }

    fun logTail(n: Int): List<String> = synchronized(logBuf) { logBuf.takeLast(n) }

    /** Sound events are only queued while the Game Space screen is visible, so MLBB's audio is never disturbed. */
    private fun sfx(s: Sfx) {
        if (!uiVisible) return
        sfxQ.add(s)
        while (sfxQ.size > 4) sfxQ.poll()
    }

    fun drainSfx(): List<Sfx> {
        val out = ArrayList<Sfx>()
        while (true) { val s = sfxQ.poll() ?: break; out.add(s) }
        return out
    }

    // ---- UI actions ----
    fun applyNow() { h?.post { applyProfile(false) } }
    fun restoreNow() { h?.post { doRestore("MANUAL RESTORE") } }
    fun profileChanged() {
        h?.post {
            if (applied) { val by = appliedBy; doRestore("PROFILE CHANGED"); applyProfile(by == "AUTO") }
            else if (gameFg && prefs?.getB("auto_mode", true) == true) applyProfile(true)
        }
    }
    fun redetect() { h?.post { detected = false }; kick() }

    private fun onShizukuChange(why: String) {
        log("SHIZUKU: $why")
        h?.post {
            if (why == "BINDER" || why == "PERMISSION") { detected = false; recoveryDone = false }
            if (why == "DEAD") {
                shizuku = ShizukuState.DISCONNECTED
                gameFg = false
                activeGame = null
                applied = false
                coreOptimized = false
                thermalLevel = 0
            }
            kick()
        }
    }

    // ---- main loop ----
    private fun tick(): Long {
        val ctx = app ?: return 5000L
        shizuku = ShizukuBridge.state()
        hzActual = DisplayCtl.current(ctx)
        battTemp = batteryTemp(ctx)
        if (!screenOn) return 15000L

        if (shizuku != ShizukuState.CONNECTED) {
            gameFg = false
            fps = -1f; fpsAvg = -1f; cpuPct = -1f; cpuMhz = -1; cpuTemp = -1f; gpuPct = -1f; gpuMhz = -1; gpuTemp = -1f
            calc.resetCpu(); calc.resetFps()
            return if (uiVisible) 1500L else 8000L
        }
        if (!detected) runDetect(ctx)
        if (!uiVisible && !watcherActive && !gameFg) return 20000L

        cycle++
        val full = uiVisible || gameFg
        if (!full) {
            evalFg(Sampler.sampleFg()?.fg)
            return 3000L
        }
        val checkFg = !gameFg || cycle % 3L == 0L
        if (gameFg && fps >= 0f && layers.isEmpty()) discoverLayers()
        if (gameFg && layers.isEmpty() && System.currentTimeMillis() - layerAt > 4000L) discoverLayers()
        val layer = if (gameFg && layers.isNotEmpty()) layers[layerIdx % layers.size] else ""
        val gfxPkg = if (gameFg && fpsMiss >= 3) (activeGame?.pkg ?: "") else ""
        val raw = Sampler.sampleFull(gpu?.dir ?: "", layer, checkFg, gfxPkg, cycle % 5L == 0L)
        if (raw == null) return 1500L
        updateMetrics(raw)
        evalThermal()
        adjust()
        evalFg(raw.fg)
        sampleSeq++
        return 1000L
    }

    private fun runDetect(ctx: Context) {
        val info = Detect.run(ctx)
        if (info == null) { log("DETECT: could not read the device (will retry)"); return }
        detected = true
        gpu = info.gpu
        maxHz = DisplayCtl.maxRate(ctx)
        targetFps = AutoPlan.targetFor(maxHz)
        log("DEVICE: " + info.manufacturer + " " + info.model + " · Android SDK " + info.sdk)
        log("SOC: " + info.socLine + " · GPU: " + info.gpuVendor)
        log("CAPABILITIES: " + Caps.all().filter { it.supported }.joinToString(" ") { it.name })
        val no = Caps.all().filter { !it.supported }
        if (no.isNotEmpty()) log("NOT AVAILABLE: " + no.joinToString(", ") { it.name })
    }

    private fun updateMetrics(raw: Raw) {
        cpuPct = calc.cpu(raw.stat)
        val mx = raw.freqs.maxOrNull()
        cpuMhz = if (mx == null) -1 else (mx / 1000L).toInt()
        var ct = -1f
        var gt = -1f
        for ((id, tv) in raw.temps) {
            val type = raw.types[id] ?: continue
            val t = Sampler.normTemp(tv)
            if (t < -20f || t > 150f) continue
            if (Sampler.isGpuZone(type)) { if (t > gt) gt = t }
            else if (Sampler.isCpuZone(type)) { if (t > ct) ct = t }
        }
        cpuTemp = ct
        gpuTemp = gt
        val gf = raw.gpuF?.trim()?.toLongOrNull()
        gpuMhz = if (gf == null) -1 else Sampler.rawToMhz(gf)
        gpuPct = parseGpuBusy(raw.gpuB)
        raw.therm?.let { line ->
            Regex("(\\d+)").find(line)?.groupValues?.get(1)?.toIntOrNull()?.let { thermalStatus = it }
        }
        verifyGpu()

        if (gameFg) {
            var f = calc.fps(raw.fps)
            var src = "SURFACEFLINGER"
            if (f < 0f && raw.gfx.isNotEmpty()) { f = calc.fpsGfx(raw.gfx); src = "GFXINFO" }
            fps = f
            if (f < 0f) {
                fpsMiss++
                fpsNote = "No frame data from SurfaceFlinger or gfxinfo"
                zeroFps++
                frameMs = -1f; fps1Low = -1f; jank = -1
                if (fpsMiss == 12 && !fpsCapSet) { fpsCapSet = true; Caps.put(Capability(Cap.FPS_MONITOR, false, false, false, "No frame timing source answered", "SurfaceFlinger / gfxinfo")) }
            } else {
                fpsMiss = 0
                fpsSource = src
                if (f == 0f) { fpsNote = "No new frames"; zeroFps++ }
                else {
                    fpsNote = ""; zeroFps = 0
                    fpsHist.addLast(f)
                    while (fpsHist.size > 20) fpsHist.pollFirst()
                    fpsAvg = fpsHist.sum() / fpsHist.size
                    if (!fpsCapSet) { fpsCapSet = true; Caps.put(Capability(Cap.FPS_MONITOR, true, false, true, "Frames read from $src", src)) }
                }
                val st = calc.stats
                frameMs = st?.frameMs ?: -1f
                fps1Low = st?.low1 ?: -1f
                jank = if (st != null && st.frameMs > 0f) st.jank else -1
            }
            if (zeroFps >= 3 && layers.size > 1) { layerIdx++; zeroFps = 0; calc.resetFps() }
        } else {
            fps = -1f; fpsAvg = -1f; fps1Low = -1f; frameMs = -1f; jank = -1
            fpsNote = ""
        }
    }

    private fun parseGpuBusy(lines: List<String>): Float {
        for (l in lines) {
            val t = l.trim()
            if (t.contains("%")) {
                val v = t.replace("%", "").trim().toFloatOrNull()
                if (v != null) return v.coerceIn(0f, 100f)
            }
        }
        for (l in lines) {
            val p = l.trim().split(Regex("\\s+"))
            if (p.size == 2) {
                val a = p[0].toLongOrNull()
                val b = p[1].toLongOrNull()
                if (a != null && b != null && b > 0L) return (a * 100f / b).coerceIn(0f, 100f)
            }
        }
        return -1f
    }

    private fun discoverLayers() {
        layerAt = System.currentTimeMillis()
        val pkg = activeGame?.pkg ?: return
        val r = ShizukuBridge.sh("dumpsys SurfaceFlinger --list 2>/dev/null | grep '" + pkg + "'", 5000L, "FPS_MONITOR")
        val all = r.stdout.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("Background for") && !it.contains("Bounds for") }
        val sv = all.filter { it.startsWith("SurfaceView[") }
        layers = if (sv.isNotEmpty()) sv + all.filter { !it.startsWith("SurfaceView[") } else all
        layerIdx = 0
        if (layers.isNotEmpty()) log("FPS source: " + layers[0].take(48))
    }

    // ---- game detection ----
    private fun evalFg(txt: String?) {
        if (txt == null) return
        if (txt.isBlank()) {
            fgBlank++
            if (fgBlank >= 5) fgKnown = false
            return
        }
        fgBlank = 0
        fgKnown = true
        val m = ProfileStore.matchForeground(txt)
        val p = prefs
        if (m != null) {
            miss = 0
            if (gameFg && activeGame?.pkg != m.pkg) onGameStop()
            if (!gameFg) onGameStart(m)
        } else {
            if (gameFg) {
                miss++
                if (miss >= 2) onGameStop()
            } else if (!recoveryDone) {
                recoveryDone = true
                if (p != null && !applied && Applier.hasJournal(p)) doRestore("CRASH RECOVERY")
            }
        }
        recoveryDone = true
    }

    private fun onGameStart(m: GameProfile) {
        gameFg = true
        activeGame = m
        miss = 0
        layers = emptyList(); layerIdx = 0; layerAt = 0L; zeroFps = 0; fpsMiss = 0
        fpsHist.clear(); fpsCapSet = Caps.get(Cap.FPS_MONITOR) != null
        calc.resetFps()
        log("GAME DETECTED: " + m.name)
        sfx(Sfx.GAME_DETECTED)
        val p = prefs ?: return
        if (p.getB("auto_mode", true) && m.autoOptimize && m.perfMode != 0) applyProfile(true)
        else log("SANJU AUTO is off for this game: monitoring only")
        kick()
    }

    private fun onGameStop() {
        val g = activeGame
        gameFg = false
        activeGame = null
        miss = 0
        fps = -1f
        log("GAME CLOSED" + (if (g != null) ": " + g.name else ""))
        if (applied && appliedBy == "AUTO" && (g?.restoreOnExit != false)) doRestore("GAME EXITED")
    }

    // ---- apply / verify / restore ----
    private fun stepLog(name: String, s: Step) { log(name + ": " + s.text()) }

    private fun applyProfile(auto: Boolean) {
        val ctx = app ?: return
        val p = prefs ?: return
        if (shizuku != ShizukuState.CONNECTED) { log("SHIZUKU REQUIRED: nothing applied"); steps["DISPLAY"] = Step(St.UNSUPPORTED, "SHIZUKU REQUIRED"); return }
        val prof = (if (auto) activeGame else null) ?: ProfileStore.selected()
        if (prof.perfMode == 0) { log("PERFORMANCE MODE OFF for " + prof.name + ": nothing applied"); return }
        log("SANJU AUTO: optimizing for " + prof.name)
        sfx(Sfx.BOOST_ON)
        val plan = AutoPlan.compute(ctx, prof.perfMode)
        maxHz = plan.maxHz; targetFps = plan.targetFps; hzReq = plan.reqHz
        log(plan.note)
        steps["DISPLAY"] = Applier.applyDisplay(p, plan.reqHz)
        stepLog("DISPLAY", step("DISPLAY"))
        if (prof.perfMode >= 2) {
            steps["GAMEMODE"] = Applier.applyGameMode(p, prof.pkg, plan.targetFps)
            steps["CPU"] = if (thermalLevel >= 3) Step(St.NOT_REQUESTED, "held back: thermal protection") else Applier.applyCpu(p, if (prof.perfMode >= 2) 0.85f else 0.75f)
        } else {
            steps["GAMEMODE"] = Step(St.NOT_REQUESTED, "BALANCED mode")
            steps["CPU"] = Step(St.NOT_REQUESTED, "BALANCED mode")
        }
        stepLog("GAME MODE", step("GAMEMODE")); stepLog("CPU", step("CPU"))
        gpuCfg = if (prof.perfMode >= 2) p.getI("gpu_level", 2).coerceIn(0, 2) else 0
        cpuReleased = thermalLevel >= 3
        applyGpuLevel(desiredGpu())
        stepLog("GPU", step("GPU"))
        steps["FX"] = Applier.applyFx(p, prof.effect); stepLog("EFFECTS", step("FX"))
        steps["TOUCH"] = Applier.applyTouch(p, prof.touch); stepLog("TOUCH", step("TOUCH"))
        steps["DNS"] = Applier.applyDns(p, prof.dns); stepLog("DNS", step("DNS"))
        steps["BG"] = if (p.getB("bg_trim", true) && prof.perfMode >= 2)
            Applier.applyBackground(p, prof.pkg, ctx.packageName) else Step(St.NOT_REQUESTED, "off")
        stepLog("BACKGROUND", step("BG"))
        val coreSteps = listOf(step("GAMEMODE"), step("CPU"), step("BG"))
        coreOptimized = coreSteps.any { it.st == St.VERIFIED || it.st == St.APPLIED }
        applied = Applier.hasJournal(p)
        appliedBy = if (coreOptimized || applied) (if (auto) "AUTO" else "MANUAL") else ""
        if (coreOptimized) log("CORE BOOST: at least one real game-performance control is active")
        else log("CORE BOOST: NO performance control was verified/applied; game was not marked optimized")
        if (coreOptimized) sfx(Sfx.OPTIMIZE_DONE)
        hzChecks = 0
        h?.postDelayed({ verifyHz() }, 1800L)
        h?.postDelayed({ verifyHz() }, 5000L)
    }

    private fun desiredGpu(): Int = when {
        prefs?.getB("thermal_guard", true) != true -> gpuCfg
        thermalLevel >= 3 -> -1
        thermalLevel == 2 -> 0
        else -> gpuCfg
    }

    private fun applyGpuLevel(level: Int) {
        val p = prefs ?: return
        if (level < 0) {
            Applier.releaseGpu(p)
            gpuFloorMhz = -1
            gpuLevelApplied = -1
            steps["GPU"] = Step(St.NOT_REQUESTED, "released (thermal protection)")
            return
        }
        val r = Applier.applyGpu(p, gpu, level)
        steps["GPU"] = r.step
        gpuFloorMhz = r.floorMhz
        gpuLevelApplied = level
        gpuApplyAt = System.currentTimeMillis()
    }

    private fun verifyGpu() {
        val s = step("GPU")
        if (gpuFloorMhz > 0 && s.st == St.APPLIED && gpuMhz > 0 && gpuMhz >= gpuFloorMhz * 0.95f) {
            steps["GPU"] = Step(St.VERIFIED, "clock " + gpuMhz + " MHz at floor " + gpuFloorMhz + " MHz")
            Caps.markVerified(Cap.GPU_PERFORMANCE)
        }
    }

    private fun verifyHz() {
        val ctx = app ?: return
        val s = step("DISPLAY")
        if (!applied || hzReq <= 0 || s.st != St.REQUESTED) return
        hzChecks++
        val a = DisplayCtl.current(ctx)
        hzActual = a
        if (a >= hzReq - 1.5f) {
            steps["DISPLAY"] = Step(St.VERIFIED, "actual " + Math.round(a) + " Hz")
            Caps.markVerified(Cap.DISPLAY_HIGH_REFRESH)
            log("DISPLAY: " + hzReq + " Hz VERIFIED (actual " + Math.round(a) + " Hz)")
        } else if (hzChecks >= 2) {
            steps["DISPLAY"] = Step(St.FAILED, "requested " + hzReq + " Hz, panel still at " + Math.round(a) + " Hz. This device ignores the system request")
            log("DISPLAY: requested " + hzReq + " Hz but actual is " + Math.round(a) + " Hz. This device ignores the system request")
        }
    }

    /** NORMAL -> PERFORMANCE -> THERMAL WARNING -> THERMAL PROTECTION, with a cool-down before stepping back. */
    private fun evalThermal() {
        val soc = maxOf(cpuTemp, gpuTemp)
        var raw = if (applied) 1 else 0
        if (thermalStatus >= 2 || battTemp >= 42f || soc >= 75f) raw = 2
        if (thermalStatus >= 3 || battTemp >= 45f || soc >= 85f) raw = 3
        val cur = thermalLevel
        if (raw > cur) {
            thermalLevel = raw
            coolTicks = 0
            if (raw >= 2) { log("THERMAL: " + THERMAL_NAMES[raw]); sfx(Sfx.WARNING) }
        } else if (raw < cur) {
            coolTicks++
            if (coolTicks >= 15) {
                thermalLevel = raw
                coolTicks = 0
                log("THERMAL: back to " + THERMAL_NAMES[raw])
            }
        } else coolTicks = 0
    }

    /** Dynamic adjustment: protect the device first, then restore the configured level once it has cooled down. */
    private fun adjust() {
        val p = prefs ?: return
        if (!applied) return
        if (Caps.controllable(Cap.GPU_PERFORMANCE) && gpuCfg != -2) {
            val want = desiredGpu()
            if (want != gpuLevelApplied) {
                log("ADJUST: GPU " + (if (want < 0) "released" else Applier.GPU_LEVELS[want]) + " (" + THERMAL_NAMES[thermalLevel] + ")")
                applyGpuLevel(want)
            }
        }
        if (prefs?.getB("thermal_guard", true) == true) {
            if (thermalLevel >= 3 && !cpuReleased) {
                Applier.releaseCpu(p)
                cpuReleased = true
                steps["CPU"] = Step(St.NOT_REQUESTED, "released (thermal protection)")
                log("ADJUST: CPU performance mode released")
            } else if (thermalLevel < 2 && cpuReleased && (activeGame?.perfMode ?: ProfileStore.selected().perfMode) >= 2) {
                steps["CPU"] = Applier.applyCpu(p)
                cpuReleased = false
                log("ADJUST: CPU performance mode back on")
            }
        }
    }

    private fun doRestore(reason: String) {
        val p = prefs ?: return
        log("$reason: RESTORING")
        val lines = try { Applier.restore(p) } catch (t: Throwable) { listOf("RESTORE ERROR: " + (t.message ?: "")) }
        for (l in lines) log(l)
        applied = false
        coreOptimized = false
        appliedBy = ""
        hzReq = 0
        gpuCfg = -2; gpuLevelApplied = -2; gpuFloorMhz = -1; cpuReleased = false
        steps.clear()
        sfx(Sfx.TOGGLE_OFF)
    }

    private fun batteryTemp(ctx: Context): Float {
        return try {
            val i: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val t = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
            if (t < 0) -1f else t / 10f
        } catch (e: Throwable) { -1f }
    }
}
