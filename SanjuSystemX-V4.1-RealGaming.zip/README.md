# SanjuSystemX V4.1 (Real Gaming Boost)

Shizuku-powered gaming HUD for Mobile Legends (`com.mobile.legends`). Package: `com.sanju.systemx`.

## Build
GitHub: push the files (or this zip) to `main` -> Actions -> *Build SanjuSystemX APK* -> download the artifact.
Local: `gradle assembleDebug assembleRelease` -> `app/build/outputs/apk/debug/app-debug.apk`

## What is real, what is not
| Feature | How | Honest status |
|---|---|---|
| Shizuku status | binder + permission check | CONNECTED / DISCONNECTED / PERMISSION REQUIRED / UNSUPPORTED |
| MLBB detection | shell `dumpsys` foreground check via Shizuku | needs Shizuku; shows "DETECTION UNAVAILABLE" if the OS prints nothing |
| Refresh rate | AOSP `min_refresh_rate` / `peak_refresh_rate`, plus Vivo/iQOO OriginOS refresh selectors when applicable | REQUESTED vs ACTUAL is always shown. OriginOS vendor keys are read back, then the real panel is checked before VERIFIED |
| FPS target 60/90/120 | picks the display rate and is compared with measured FPS | cannot raise a game's internal FPS cap |
| Actual FPS | SurfaceFlinger frame timestamps of the MLBB layer | shows UNAVAILABLE when the device gives no data. Never invented |
| CPU usage/freq/temp | /proc/stat, cpufreq, thermal zones (via Shizuku) | UNAVAILABLE if unreadable |
| GPU usage/freq/temp | read-only vendor files (Adreno kgsl, devfreq) | UNSUPPORTED if not exposed |
| GPU boost | writes a real devfreq `min_freq` only when the shell can write it and read-back succeeds | otherwise UNSUPPORTED; no fake clock value is shown |
| Game Mode boost | Android GameManager: `cmd game set --mode 2 --downscale 0.90 --fps N` + `cmd game mode performance` with `device_config game_overlay` fallback | `list-modes` + `list-configs`/overlay read-back; only then VERIFIED |
| Touch response | Android `long_press_timeout` only | clearly labeled as touch-and-hold timing, not raw gaming touch latency; Vivo Super Touch remains OEM-controlled |
| Restore | original values saved before changing, restored when MLBB exits | journal also restores after a crash |

## Notes
- Background watcher = foreground service + notification, needed to detect MLBB while the game is in front. After a reboot: start Shizuku, then open SanjuSystemX once.
- Intro: 5 s cinematic, tap to skip. Shizuku/system init starts immediately and does not wait for it.
- Layout: a left rail switches between HOME, PERFORMANCE, GPU / CPU, DISPLAY and SETTINGS pages (`ui/Hud.kt`).
- Eye sound: `res/raw/sfx_eye.wav` is the owner-supplied Itachi intro clip, trimmed to 2.4 s and played at 0.85 s so its peak lands as the eye opens. To use a different clip, replace that file (same name; .wav/.ogg/.mp3 all load by name).
- Sounds are original synthesized tones in `res/raw` (replace by same file name). They use `SoundPool` with no audio focus and never change volume.
- Icon: your Mangekyo image (`res/drawable-nodpi/ic_launcher_fg.png`).


## V4.1 real-functionality upgrade
- `shizuku/ShizukuBridge.kt`: one privileged execution layer, `CommandResult` (stdout, stderr, exit code, duration, capability, error reason), timeouts, binder received/dead + permission listeners.
- `caps/`, `device/Detect.kt`: capability registry filled from what the device really exposes (display, game mode, GPU, CPU, thermal, touch, colour, DNS, ping, FPS).
- `game/GameProfile.kt`: game profiles (MLBB built in, ADD GAME for others).
- `optimizer/`: `AutoPlan` plus real GameManager intervention (90% default game render scale), reversible CPU frequency-floor fallback, Vivo/iQOO refresh selectors, background trimming, and exact restore journaling.
- `net/NetEngine.kt`: real ping / jitter / packet loss.
- `monitor/Sampler.kt`: SurfaceFlinger frame timing, gfxinfo fallback, average / 1% low / frame time / jank, thermal status.
- `ui/Hud.kt`: GAME, PERFORMANCE, DISPLAY, EFFECTS, NETWORK, TOUCH, MONITOR, SETTINGS.
- `Engine` now separates `BOOST ACTIVE` from a mere settings journal: the home screen only says optimized when a real game-performance control is APPLIED/VERIFIED.
- Build: GitHub Actions runs `gradle assembleDebug assembleRelease`. Locally: `gradle :app:assembleDebug` (there is no Gradle wrapper in this repository).

### V4.1 changes
- 120 Hz is requested when the current-resolution display actually exposes 120 Hz.
- FPS target is 120 on a real 120-Hz panel; it is still only a target/hint, never a fake FPS value.
- Actual FPS remains SurfaceFlinger/gfxinfo measured and can show UNAVAILABLE.
- Added Thermal Guard ON/OFF as an app-level adaptive policy. OFF never disables Android/kernel thermal safety.
- Fixed the GameManager command path: `cmd game mode performance` is the mode switch; intervention config uses numeric mode 2.
- Added 90% game render-scale intervention to reduce GPU workload without changing the phone-wide display resolution.
- Added Vivo/iQOO OriginOS refresh selectors as a fallback to the standard AOSP refresh keys.
- Added reversible CPU cpufreq-floor fallback when Android fixed-performance mode is unavailable but the shell can write the policy.
- Background optimization defaults ON in PERFORMANCE mode.
- UI explicitly distinguishes TARGET from ACTUAL for Hz/FPS and `BOOST ACTIVE` from a failed/empty optimization run.
