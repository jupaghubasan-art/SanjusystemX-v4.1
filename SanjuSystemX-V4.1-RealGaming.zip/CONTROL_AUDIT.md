# SanjuSystemX V3 - control audit

Every control, the backend it calls, what it needs, how success is verified, what happens on failure, how it is restored.
Source-level audit only. V4.1 changes focus the automatic boost on Android GameManager interventions and Vivo/iQOO refresh controls; device-side verification is still required for the final performance result.

| Control (section) | Backend | Needs (capability) | Verified by | On failure | Restore |
|---|---|---|---|---|---|
| SANJU AUTO toggle (GAME) | `Engine.evalFg` -> `applyProfile(auto)` when a profile's package is foreground | Shizuku | steps below | monitoring only, logged | n/a |
| PERFORMANCE MODE OFF/BALANCED/PERFORMANCE (GAME) | `AutoPlan.compute` + which steps run | Shizuku | steps below | step shows FAILED / UNSUPPORTED | journal |
| Auto-optimize / Restore on exit (GAME) | `GameProfile` flags read by Engine | none | n/a | n/a | n/a |
| LAUNCH / SWITCH / ADD GAME (GAME) | `getLaunchIntentForPackage`, `ProfileStore` | package visible (manifest `queries`) | toast if not installed | toast | n/a |
| APPLY NOW / RESTORE (GAME) | `Engine.applyNow/restoreNow` -> `Applier.*` / `Applier.restore` | Shizuku | steps | log | journal replay |
| Display request (DISPLAY, automatic) | `settings put system min_refresh_rate / peak_refresh_rate` (+ `user_refresh_rate` if present), `Applier.applyDisplay` | DISPLAY_HIGH_REFRESH (panel >= 90 Hz) | `Display.refreshRate` read after 1.8 s and 5 s -> VERIFIED or FAILED | FAILED "panel still at X Hz" | journal restores both keys |
| Game Mode + render intervention (PERFORMANCE, automatic) | Android GameManager: `cmd game set --mode 2 --downscale 0.90 --fps N <pkg>` then `cmd game mode performance <pkg>` | GAME_MODE (Android 12+/device GameManager) | `cmd game list-modes` + `cmd game list-configs` read-back; FPS monitor remains the gameplay measurement | FAILED with command output | `cmd game reset <pkg>` then restore previous standard/performance/battery mode |
| CPU performance (PERFORMANCE, automatic) | `cmd power set-fixed-performance-mode-enabled true`; fallback to writable `/sys/devices/system/cpu/cpufreq/policy*/scaling_min_freq` floor | CPU_PERFORMANCE | power-mode read-back or sysfs read-back | FAILED / UNSUPPORTED | restore original fixed mode and CPU min-frequency journal entries |
| GPU ceiling BALANCED/PERFORMANCE/MAXIMUM (PERFORMANCE) | picks a real step from `available_frequencies`, writes devfreq `min_freq`, reads it back | GPU_PERFORMANCE (writable for the shell user) | `min_freq` read-back = APPLIED, then `cur_freq` >= 95% of floor = VERIFIED | FAILED "kernel refused" / UNSUPPORTED | writes original `min_freq` back |
| Background optimization (PERFORMANCE) | `pm list packages -3` minus protected set, then `am kill` (never force-stop) | Shizuku | process list before/after | APPLIED "Android kept them" | nothing to restore, apps restart on demand |
| Effects COOL/VIVID/CINEMATIC (EFFECTS) | `settings put secure display_color_mode` (verifiable) and/or SurfaceFlinger 1022/1015 colour transform (no read-back) | DISPLAY_COLOR | colour-mode read-back = VERIFIED; SurfaceFlinger only = APPLIED | FAILED / UNSUPPORTED | journal: mode setting + SurfaceFlinger reset |
| Effects PERFORMANCE/DEFAULT (EFFECTS) | restores colour journal entries | none | n/a | n/a | n/a |
| Touch FAST/SLOW (TOUCH) | `settings put secure long_press_timeout 250/700` | TOUCH_RESPONSE | settings read-back = VERIFIED | FAILED | journal restores your value; DEFAULT restores now |
| DNS CLOUDFLARE/GOOGLE/QUAD9 (NETWORK) | `settings put global private_dns_specifier/private_dns_mode` | DNS | settings read-back = VERIFIED | FAILED | journal restores both; AUTO restores now |
| Ping / jitter / loss (NETWORK, MONITOR) | shell `ping -c 5` to 1.1.1.1 (then 8.8.8.8) every 6 s while visible/in game | PING | parsed from real replies | "--" | n/a |
| FPS / 1% low / frame time / jank (MONITOR) | `dumpsys SurfaceFlinger --latency <layer>`; fallback `dumpsys gfxinfo <pkg> framestats` | FPS_MONITOR | measured | "--" and a note | n/a |
| CPU / GPU / temperatures (MONITOR) | `/proc/stat`, cpufreq, kgsl/devfreq, thermal zones, battery | CPU_MONITOR / GPU_MONITOR | measured | "--" | n/a |
| Thermal protection (PERFORMANCE, automatic) | thermalservice status, SoC zones, battery temp thresholds with 15 s cool-down | THERMAL | n/a | n/a | releases GPU floor and CPU mode |
| Sound / haptics / volume / watcher (SETTINGS) | prefs + `SfxPlayer`, foreground service | none | n/a | n/a | n/a |
| RE-DETECT DEVICE (SETTINGS) | `Engine.redetect` -> `Detect.run` | Shizuku | capability list | log | n/a |

Lifecycle: Shizuku binder received/dead listeners re-run detection and crash recovery; screen off restores and re-applies on screen on; game exit or crash restores; an app restart replays the journal.

| Thermal Guard toggle | Sanju adaptive policy | none | preference read-back | does not disable OS/kernel thermal protection | preference only |
